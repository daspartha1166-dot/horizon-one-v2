/**
 * Horizen — turns a person's Spotify history into Horizen listening history.
 *
 * Each distinct Spotify track is matched to a song on YouTube Music (artist + title must both agree),
 * the song is added to the local database, and every listen is recorded as an event with its
 * original timestamp. The recommendation engine then learns from it exactly as if the songs had been
 * played in Horizen. Importing the same file twice is safe: events that already exist are skipped.
 */

package com.metrolist.music.recommendation.spotify

import com.metrolist.innertube.YouTube
import com.metrolist.innertube.models.SongItem
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.Event
import com.metrolist.music.models.toMediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.LocalDateTime
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

enum class ImportPhase { IDLE, READING, MATCHING, DONE, FAILED, CANCELLED }

data class ImportProgress(
    val phase: ImportPhase = ImportPhase.IDLE,
    val processed: Int = 0,
    val total: Int = 0,
    val matched: Int = 0,
    val unmatched: Int = 0,
    val eventsAdded: Int = 0,
    val likedAdded: Int = 0,
    val skippedTracks: Int = 0,
    val message: String? = null,
)

internal object ImportConfig {
    /** Most-played tracks first; the long tail adds little signal but costs many searches. */
    const val MAX_TRACKS = 2_000
    const val CONCURRENT_SEARCHES = 4
    const val MAX_LIKED = 1_000
}

@Singleton
class SpotifyHistoryImporter
@Inject
constructor(
    private val database: MusicDatabase,
) {
    /**
     * Runs the import. [onProgress] is called after every track. Cancel by cancelling the calling coroutine.
     */
    suspend fun importHistory(
        plays: List<SpotifyPlay>,
        liked: List<SpotifyLikedTrack>,
        onProgress: (ImportProgress) -> Unit,
    ) {
        // Group listens per distinct track, most-listened first.
        val grouped =
            plays
                .groupBy { key(it.artist, it.track) }
                .values
                .sortedByDescending { group -> group.sumOf { it.msPlayed } }
        val tracks = grouped.take(ImportConfig.MAX_TRACKS)
        val likedKeys = liked.map { key(it.artist, it.track) }.toHashSet()
        val playedKeys = tracks.map { key(it.first().artist, it.first().track) }.toHashSet()
        val extraLiked =
            liked
                .distinctBy { key(it.artist, it.track) }
                .filter { key(it.artist, it.track) !in playedKeys }
                .take(ImportConfig.MAX_LIKED)

        val total = tracks.size + extraLiked.size
        val processed = AtomicInteger()
        val matched = AtomicInteger()
        val unmatched = AtomicInteger()
        val events = AtomicInteger()
        val likedAdded = AtomicInteger()
        val skipped = (grouped.size - tracks.size).coerceAtLeast(0)

        fun report() =
            onProgress(
                ImportProgress(
                    phase = ImportPhase.MATCHING,
                    processed = processed.get(),
                    total = total,
                    matched = matched.get(),
                    unmatched = unmatched.get(),
                    eventsAdded = events.get(),
                    likedAdded = likedAdded.get(),
                    skippedTracks = skipped,
                ),
            )
        report()

        val semaphore = Semaphore(ImportConfig.CONCURRENT_SEARCHES)
        coroutineScope {
            val historyJobs =
                tracks.map { group ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            val first = group.first()
                            val item = findOnYouTubeMusic(first.artist, first.track)
                            if (item == null) {
                                unmatched.incrementAndGet()
                            } else {
                                matched.incrementAndGet()
                                val isLiked = key(first.artist, first.track) in likedKeys
                                val result = store(item, group, isLiked)
                                events.addAndGet(result.eventsAdded)
                                if (result.newlyLiked) likedAdded.incrementAndGet()
                            }
                            processed.incrementAndGet()
                            report()
                        }
                    }
                }
            val likedJobs =
                extraLiked.map { l ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            val item = findOnYouTubeMusic(l.artist, l.track)
                            if (item == null) {
                                unmatched.incrementAndGet()
                            } else {
                                matched.incrementAndGet()
                                if (store(item, emptyList(), liked = true).newlyLiked) likedAdded.incrementAndGet()
                            }
                            processed.incrementAndGet()
                            report()
                        }
                    }
                }
            (historyJobs + likedJobs).awaitAll()
        }

        onProgress(
            ImportProgress(
                phase = ImportPhase.DONE,
                processed = total,
                total = total,
                matched = matched.get(),
                unmatched = unmatched.get(),
                eventsAdded = events.get(),
                likedAdded = likedAdded.get(),
                skippedTracks = skipped,
            ),
        )
    }

    private class StoreResult(val eventsAdded: Int, val newlyLiked: Boolean)

    /** Adds the song, its listens (skipping ones already present) and, if requested, the like. */
    private fun store(
        item: SongItem,
        listens: List<SpotifyPlay>,
        liked: Boolean,
    ): StoreResult {
        database.insert(item.toMediaMetadata())

        var added = 0
        var addedPlayTime = 0L
        for (play in listens) {
            if (database.eventCount(item.id, play.playedAt) > 0) continue
            database.insert(Event(songId = item.id, timestamp = play.playedAt, playTime = play.msPlayed))
            added++
            addedPlayTime += play.msPlayed
        }
        if (addedPlayTime > 0) database.incrementTotalPlayTime(item.id, addedPlayTime)

        var newlyLiked = false
        if (liked) {
            val entity = database.getSongByIdBlocking(item.id)?.song
            if (entity != null && !entity.liked) {
                database.update(entity.copy(liked = true, likedDate = LocalDateTime.now()))
                newlyLiked = true
            }
        }
        return StoreResult(added, newlyLiked)
    }

    /** Searches YouTube Music and returns the first result whose artist AND title agree with Spotify's. */
    private suspend fun findOnYouTubeMusic(
        artist: String,
        track: String,
    ): SongItem? {
        val results =
            YouTube
                .search("$artist $track", YouTube.SearchFilter.FILTER_SONG)
                .getOrNull()
                ?.items
                ?.filterIsInstance<SongItem>()
                .orEmpty()
        return results
            .map { it to matchScore(it, artist, track) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
    }

    internal companion object {
        private val nonWord = Regex("[^\\p{L}\\p{N}]+")

        fun normalize(text: String): String = text.lowercase().replace(nonWord, " ").trim()

        fun key(
            artist: String,
            track: String,
        ) = normalize(artist) + "|" + normalize(track)

        /**
         * 0 = reject. Both the title and an artist must agree (exact = 2, one contains the other = 1),
         * so "Song - Remastered" still matches "Song" but a cover by someone else does not.
         */
        fun matchScore(
            item: SongItem,
            artist: String,
            track: String,
        ): Int {
            val wantTitle = normalize(track)
            val gotTitle = normalize(item.title)
            val titleScore =
                when {
                    wantTitle.isEmpty() || gotTitle.isEmpty() -> 0
                    wantTitle == gotTitle -> 2
                    gotTitle.contains(wantTitle) || wantTitle.contains(gotTitle) -> 1
                    else -> 0
                }
            val wantArtist = normalize(artist)
            val artistScore =
                item.artists.maxOfOrNull { a ->
                    val got = normalize(a.name)
                    when {
                        got.isEmpty() || wantArtist.isEmpty() -> 0
                        got == wantArtist -> 2
                        got.contains(wantArtist) || wantArtist.contains(got) -> 1
                        else -> 0
                    }
                } ?: 0
            return if (titleScore == 0 || artistScore == 0) 0 else titleScore + artistScore
        }
    }
}
