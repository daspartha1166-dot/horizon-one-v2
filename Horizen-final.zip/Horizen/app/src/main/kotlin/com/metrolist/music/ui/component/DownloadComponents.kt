/**
 * Horizen — modern download components.
 *
 * - [DownloadBadge]: compact state indicator for list rows (progress ring / done check).
 * - [PlayerDownloadButton]: one-tap download / cancel / remove button for the player.
 * - [downloadProgress]: shared helper that turns a media3 [Download] into 0..1 progress.
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadService
import com.metrolist.music.LocalDownloadUtil
import com.metrolist.music.R
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.playback.ExoDownloadService

/** Returns 0f..1f progress, or null when the percentage is not known yet. */
fun downloadProgress(download: Download?): Float? {
    val percent = download?.percentDownloaded ?: return null
    return if (percent < 0f) null else (percent / 100f).coerceIn(0f, 1f)
}

private fun Int?.isActive() = this == Download.STATE_QUEUED || this == Download.STATE_DOWNLOADING

/** Small status indicator used in list rows. Pass the full [Download] to get a live progress ring. */
@Composable
fun DownloadBadge(
    download: Download?,
    modifier: Modifier = Modifier,
) = DownloadBadge(state = download?.state, progress = downloadProgress(download), modifier = modifier)

@Composable
fun DownloadBadge(
    state: Int?,
    progress: Float? = null,
    modifier: Modifier = Modifier,
) {
    val kind = when {
        state == Download.STATE_COMPLETED -> 2
        state.isActive() -> 1
        else -> 0
    }
    Crossfade(targetState = kind, modifier = modifier.padding(end = 2.dp), label = "DownloadBadge") { k ->
        when (k) {
            2 -> Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.check),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(12.dp),
                )
            }

            1 -> Box(modifier = Modifier.size(18.dp), contentAlignment = Alignment.Center) {
                val animated by animateFloatAsState(
                    targetValue = progress ?: 0f,
                    animationSpec = tween(300),
                    label = "DownloadProgress",
                )
                if (progress == null) {
                    CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                } else {
                    CircularProgressIndicator(
                        progress = { animated },
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(18.dp),
                    )
                }
                Icon(
                    painter = painterResource(R.drawable.arrow_downward),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(9.dp),
                )
            }

            else -> Unit
        }
    }
}

/**
 * One-tap download button for the player.
 * idle → download · active → tap to cancel (live ring) · done → tap to remove.
 */
@Composable
fun PlayerDownloadButton(
    mediaMetadata: MediaMetadata,
    download: Download?,
    shape: Shape,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val downloadUtil = LocalDownloadUtil.current
    val state = download?.state
    val progress = downloadProgress(download)

    FilledIconButton(
        onClick = {
            if (state == null || state == Download.STATE_FAILED || state == Download.STATE_STOPPED) {
                downloadUtil.download(mediaMetadata)
            } else {
                DownloadService.sendRemoveDownload(
                    context,
                    ExoDownloadService::class.java,
                    mediaMetadata.id,
                    false,
                )
            }
        },
        shape = shape,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = containerColor,
            contentColor = contentColor,
        ),
        modifier = modifier.size(42.dp),
    ) {
        Crossfade(targetState = state, label = "PlayerDownloadIcon") { s ->
            when {
                s == Download.STATE_COMPLETED -> Icon(
                    painter = painterResource(R.drawable.offline),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                )

                s.isActive() -> Box(contentAlignment = Alignment.Center) {
                    if (progress == null) {
                        CircularProgressIndicator(
                            strokeWidth = 2.5.dp,
                            color = contentColor,
                            modifier = Modifier.size(24.dp),
                        )
                    } else {
                        CircularProgressIndicator(
                            progress = { progress },
                            strokeWidth = 2.5.dp,
                            color = contentColor,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }

                else -> Icon(
                    painter = painterResource(R.drawable.download),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}
