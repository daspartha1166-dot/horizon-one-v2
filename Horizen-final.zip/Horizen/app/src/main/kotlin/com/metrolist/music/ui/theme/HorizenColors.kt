/**
 * Horizen — signature "Obsidian & Champagne" palette.
 *
 * Deep ink-black surfaces, warm champagne-gold accents and soft ivory text.
 * Surfaces step up in tiny, cool-neutral increments so cards feel layered
 * rather than boxed. Kept in one file so the whole brand look is tweakable here.
 */

package com.metrolist.music.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

object HorizenPalette {
    // Brand
    val Champagne = Color(0xFFD9B36C)
    val ChampagneDeep = Color(0xFF8A6A25)
    val Amethyst = Color(0xFFB7A6FF)
    val AmethystDeep = Color(0xFF5B4BB5)

    // Dark surfaces (obsidian)
    val Obsidian = Color(0xFF0A0A0F)
    val InkLow = Color(0xFF101016)
    val Ink = Color(0xFF15151D)
    val InkHigh = Color(0xFF1B1B25)
    val InkHighest = Color(0xFF232330)

    // Light surfaces (ivory)
    val Ivory = Color(0xFFFBF8F3)
    val IvoryLow = Color(0xFFF5F1EA)
    val IvoryMid = Color(0xFFEFEAE1)
    val IvoryHigh = Color(0xFFE9E3D8)
}

val HorizenDarkColorScheme: ColorScheme = darkColorScheme(
    primary = HorizenPalette.Champagne,
    onPrimary = Color(0xFF2B1F00),
    primaryContainer = Color(0xFF4A3A12),
    onPrimaryContainer = Color(0xFFFFE3AE),
    inversePrimary = HorizenPalette.ChampagneDeep,

    secondary = Color(0xFFCFC2A6),
    onSecondary = Color(0xFF352E1A),
    secondaryContainer = Color(0xFF4C4430),
    onSecondaryContainer = Color(0xFFECDFC1),

    tertiary = HorizenPalette.Amethyst,
    onTertiary = Color(0xFF2A1B77),
    tertiaryContainer = Color(0xFF41328F),
    onTertiaryContainer = Color(0xFFE6DEFF),

    background = HorizenPalette.Obsidian,
    onBackground = Color(0xFFEDE8DE),
    surface = HorizenPalette.Obsidian,
    onSurface = Color(0xFFEDE8DE),
    surfaceVariant = Color(0xFF2A2933),
    onSurfaceVariant = Color(0xFFC9C4B8),
    surfaceTint = HorizenPalette.Champagne,
    inverseSurface = Color(0xFFEDE8DE),
    inverseOnSurface = Color(0xFF2F2E36),

    surfaceDim = Color(0xFF07070B),
    surfaceBright = Color(0xFF2B2B38),
    surfaceContainerLowest = Color(0xFF060609),
    surfaceContainerLow = HorizenPalette.InkLow,
    surfaceContainer = HorizenPalette.Ink,
    surfaceContainerHigh = HorizenPalette.InkHigh,
    surfaceContainerHighest = HorizenPalette.InkHighest,

    outline = Color(0xFF948F82),
    outlineVariant = Color(0xFF3A3944),
    scrim = Color(0xFF000000),

    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)

val HorizenLightColorScheme: ColorScheme = lightColorScheme(
    primary = HorizenPalette.ChampagneDeep,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE3AE),
    onPrimaryContainer = Color(0xFF2B1F00),
    inversePrimary = HorizenPalette.Champagne,

    secondary = Color(0xFF6B5F43),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF3E3BF),
    onSecondaryContainer = Color(0xFF241A04),

    tertiary = HorizenPalette.AmethystDeep,
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFE6DEFF),
    onTertiaryContainer = Color(0xFF170065),

    background = HorizenPalette.Ivory,
    onBackground = Color(0xFF1C1B18),
    surface = HorizenPalette.Ivory,
    onSurface = Color(0xFF1C1B18),
    surfaceVariant = Color(0xFFEAE2D0),
    onSurfaceVariant = Color(0xFF4B4639),
    surfaceTint = HorizenPalette.ChampagneDeep,
    inverseSurface = Color(0xFF31302B),
    inverseOnSurface = Color(0xFFF4EFE6),

    surfaceDim = Color(0xFFDDD8CE),
    surfaceBright = Color(0xFFFBF8F3),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = HorizenPalette.IvoryLow,
    surfaceContainer = HorizenPalette.IvoryMid,
    surfaceContainerHigh = HorizenPalette.IvoryHigh,
    surfaceContainerHighest = Color(0xFFE3DDD1),

    outline = Color(0xFF7D766A),
    outlineVariant = Color(0xFFCDC6B8),
    scrim = Color(0xFF000000),

    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)
