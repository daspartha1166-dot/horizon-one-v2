/**
 * Horizen — reads the data a person exports from their own Spotify account
 * (Spotify → Privacy → "Download your data").
 *
 * Supported files:
 *  - Account data:      StreamingHistory_music_N.json   (endTime, artistName, trackName, msPlayed)
 *  - Extended history:  Streaming_History_Audio_*.json  (ts, ms_played, master_metadata_*)
 *  - Library:           YourLibrary.json                (liked tracks)
 * Podcast / video history is ignored.
 */

package com.metrolist.music.recommendation.spotify

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/** One listen from Spotify's history. [playedAt] is in the phone's local time zone. */
data class SpotifyPlay(
    val artist: String,
    val track: String,
    val playedAt: LocalDateTime,
    val msPlayed: Long,
)

/** A track from the person's Spotify library ("liked"). */
data class SpotifyLikedTrack(
    val artist: String,
    val track: String,
)

data class SpotifyFileContents(
    val plays: List<SpotifyPlay> = emptyList(),
    val liked: List<SpotifyLikedTrack> = emptyList(),
)

object SpotifyHistoryParser {
    /** Plays shorter than this are accidental taps, not listens. */
    private const val MIN_MS_PLAYED = 3_000L

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val legacyTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    /** True for the file names worth reading inside Spotify's export ZIP. */
    fun isRelevantFileName(name: String): Boolean {
        val lower = name.substringAfterLast('/').lowercase()
        if (!lower.endsWith(".json")) return false
        if (lower.contains("podcast") || lower.contains("video")) return false
        return lower.startsWith("streaminghistory") ||
            lower.startsWith("streaming_history_audio") ||
            lower.startsWith("yourlibrary")
    }

    /** Parses one JSON file. Returns empty contents when the file is not a recognised Spotify export. */
    fun parse(text: String): SpotifyFileContents =
        runCatching {
            when (val root = json.parseToJsonElement(text)) {
                is JsonArray -> SpotifyFileContents(plays = root.mapNotNull { parsePlay(it) })
                is JsonObject -> SpotifyFileContents(liked = parseLibrary(root))
                else -> SpotifyFileContents()
            }
        }.getOrDefault(SpotifyFileContents())

    private fun parsePlay(element: kotlinx.serialization.json.JsonElement): SpotifyPlay? =
        runCatching {
            val o = element.jsonObject
            val artist = o.text("artistName") ?: o.text("master_metadata_album_artist_name")
            val track = o.text("trackName") ?: o.text("master_metadata_track_name")
            if (artist.isNullOrBlank() || track.isNullOrBlank()) return null // podcasts, videos, local files
            val ms = o["msPlayed"]?.jsonPrimitive?.longOrNull ?: o["ms_played"]?.jsonPrimitive?.longOrNull ?: return null
            if (ms < MIN_MS_PLAYED) return null
            val whenPlayed = parseTime(o.text("endTime") ?: o.text("ts")) ?: return null
            SpotifyPlay(artist.trim(), track.trim(), whenPlayed, ms)
        }.getOrNull()

    private fun parseLibrary(root: JsonObject): List<SpotifyLikedTrack> =
        root["tracks"]?.jsonArray
            ?.mapNotNull { element ->
                runCatching {
                    val o = element.jsonObject
                    val artist = o.text("artist")
                    val track = o.text("track")
                    if (artist.isNullOrBlank() || track.isNullOrBlank()) null else SpotifyLikedTrack(artist.trim(), track.trim())
                }.getOrNull()
            }.orEmpty()

    private fun JsonObject.text(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull

    /** Spotify timestamps are UTC; convert to local time so time-of-day habits come out right. */
    private fun parseTime(raw: String?): LocalDateTime? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            if (raw.contains('T')) {
                Instant.parse(raw).atZone(ZoneId.systemDefault()).toLocalDateTime()
            } else {
                LocalDateTime.parse(raw, legacyTime)
                    .atOffset(ZoneOffset.UTC)
                    .atZoneSameInstant(ZoneId.systemDefault())
                    .toLocalDateTime()
            }
        }.getOrNull()
    }
}
