/**
 * Horizen — design system tokens: shapes, typography and motion.
 *
 * Everything that defines how the app "feels" lives here so the look can be tuned in one place.
 */

package com.metrolist.music.ui.theme

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Softer, larger corner radii than stock Material 3 — cards and sheets feel rounder and calmer. */
val HorizenShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

private val baseTypography = Typography()

/**
 * Tighter tracking and heavier weights on titles give a confident editorial hierarchy;
 * body text stays at Material defaults for readability (also for Bengali and other scripts).
 */
val HorizenTypography = Typography(
    displayLarge = baseTypography.displayLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-1.0).sp),
    displayMedium = baseTypography.displayMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp),
    displaySmall = baseTypography.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineLarge = baseTypography.headlineLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = baseTypography.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
    headlineSmall = baseTypography.headlineSmall.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
    titleLarge = baseTypography.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleMedium = baseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.sp),
    titleSmall = baseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = baseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    labelMedium = baseTypography.labelMedium.copy(fontWeight = FontWeight.Medium),
)

/**
 * Motion language. Material "emphasized" curves: enter decelerates into place, exit accelerates away.
 * Screens fade through (the outgoing screen leaves first, the incoming one follows ~60ms later)
 * and only travel a short distance, so transitions read as smooth rather than busy.
 */
object HorizenMotion {
    val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
    val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0.0f, 0.8f, 0.15f)
    val Standard = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)

    val enterFade = tween<Float>(durationMillis = 320, delayMillis = 70, easing = Standard)
    val exitFade = tween<Float>(durationMillis = 140, easing = EmphasizedAccelerate)
    val slideEnter = tween<IntOffset>(durationMillis = 420, easing = EmphasizedDecelerate)
    val slideExit = tween<IntOffset>(durationMillis = 280, easing = EmphasizedAccelerate)

    /** Title/subtitle swap: new text rises in softly while the old one fades out first. */
    fun textSwap(): ContentTransform =
        (
            fadeIn(tween(durationMillis = 280, delayMillis = 60, easing = Standard)) +
                slideInVertically(tween(durationMillis = 320, easing = EmphasizedDecelerate)) { it / 5 }
        ) togetherWith fadeOut(tween(durationMillis = 120, easing = EmphasizedAccelerate))

    /** Snappy, slightly springy response for press feedback and small state changes. */
    fun <T> snappy() = spring<T>(dampingRatio = 0.75f, stiffness = Spring.StiffnessMedium)

    /** Calm, no-overshoot spring for size/position changes. */
    fun <T> smooth() = spring<T>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow)
}
