/**
 * Horizen — "Import Spotify history" screen.
 */

package com.metrolist.music.ui.screens.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.recommendation.spotify.ImportPhase
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.viewmodels.SpotifyImportViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotifyImportScreen(
    navController: NavController,
    viewModel: SpotifyImportViewModel = hiltViewModel(),
) {
    val progress by viewModel.progress.collectAsState()
    val picker =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            viewModel.start(uris)
        }
    val running = progress.phase == ImportPhase.READING || progress.phase == ImportPhase.MATCHING

    Column {
        TopAppBar(
            title = { Text(stringResource(R.string.sp_title)) },
            navigationIcon = {
                IconButton(
                    onClick = navController::navigateUp,
                    onLongClick = navController::backToMain,
                ) {
                    Icon(painterResource(R.drawable.arrow_back), contentDescription = null)
                }
            },
        )
        Column(
            modifier =
                Modifier
                    .weight(1f)
                    .windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Bottom))
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            InfoCard(stringResource(R.string.sp_how_title), stringResource(R.string.sp_how_body))
            InfoCard(stringResource(R.string.sp_which_title), stringResource(R.string.sp_which_body))

            when (progress.phase) {
                ImportPhase.IDLE, ImportPhase.CANCELLED, ImportPhase.FAILED -> {
                    if (progress.phase == ImportPhase.FAILED) {
                        Text(
                            text =
                                if (progress.message == "NO_DATA") {
                                    stringResource(R.string.sp_no_data)
                                } else {
                                    stringResource(R.string.sp_failed)
                                },
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    if (progress.phase == ImportPhase.CANCELLED) {
                        Text(stringResource(R.string.sp_cancelled), style = MaterialTheme.typography.bodyMedium)
                    }
                    Button(
                        onClick = { picker.launch(arrayOf("application/zip", "application/json", "application/octet-stream", "*/*")) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.sp_pick)) }
                }

                ImportPhase.READING -> {
                    Text(stringResource(R.string.sp_reading), style = MaterialTheme.typography.titleMedium)
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                ImportPhase.MATCHING -> {
                    Text(
                        stringResource(R.string.sp_matching, progress.processed, progress.total),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    LinearProgressIndicator(
                        progress = { if (progress.total == 0) 0f else progress.processed / progress.total.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Stats(progress.matched, progress.unmatched, progress.eventsAdded)
                    Text(stringResource(R.string.sp_keep_open), style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = viewModel::cancel, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.sp_cancel))
                    }
                }

                ImportPhase.DONE -> {
                    Text(stringResource(R.string.sp_done), style = MaterialTheme.typography.titleLarge)
                    Stats(progress.matched, progress.unmatched, progress.eventsAdded)
                    if (progress.likedAdded > 0) {
                        Text(stringResource(R.string.sp_liked_added, progress.likedAdded), style = MaterialTheme.typography.bodyMedium)
                    }
                    if (progress.skippedTracks > 0) {
                        Text(stringResource(R.string.sp_skipped_tail, progress.skippedTracks), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(stringResource(R.string.sp_done_hint), style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = viewModel::reset, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.sp_import_more))
                    }
                }
            }
            if (!running) Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun InfoCard(
    title: String,
    body: String,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Stats(
    matched: Int,
    unmatched: Int,
    events: Int,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatBox(matched.toString(), stringResource(R.string.sp_stat_matched), Modifier.weight(1f))
        StatBox(unmatched.toString(), stringResource(R.string.sp_stat_unmatched), Modifier.weight(1f))
        StatBox(events.toString(), stringResource(R.string.sp_stat_plays), Modifier.weight(1f))
    }
}

@Composable
private fun StatBox(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}
