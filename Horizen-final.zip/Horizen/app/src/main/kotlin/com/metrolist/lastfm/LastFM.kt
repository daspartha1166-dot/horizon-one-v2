package com.metrolist.lastfm

import com.metrolist.lastfm.models.Authentication
import com.metrolist.lastfm.models.LastFmError
import com.metrolist.lastfm.models.TokenResponse
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.*
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.statement.bodyAsText
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.security.MessageDigest

object LastFM {
    var sessionKey: String? = null

    private val json = Json {
        isLenient = true
        ignoreUnknownKeys = true
    }

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(json)
            }
            defaultRequest { url("https://ws.audioscrobbler.com/2.0/") }
            expectSuccess = false
        }
    }

    private fun Map<String, String>.apiSig(secret: String): String {
        val sorted = toSortedMap()
        val toHash = sorted.entries.joinToString("") { it.key + it.value } + secret
        val digest = MessageDigest.getInstance("MD5").digest(toHash.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun HttpRequestBuilder.lastfmParams(
        method: String,
        apiKey: String,
        secret: String,
        sessionKey: String? = null,
        extra: Map<String, String> = emptyMap(),
        format: String = "json"
    ) {
        contentType(ContentType.Application.FormUrlEncoded)
        userAgent("Metrolist (https://github.com/MetrolistGroup/Metrolist)")
        val paramsForSig = mutableMapOf(
            "method" to method,
            "api_key" to apiKey
        ).apply {
            sessionKey?.let { put("sk", it) }
            putAll(extra)
        }
        val apiSig = paramsForSig.apiSig(secret)
        setBody(FormDataContent(Parameters.build {
            paramsForSig.forEach { (k, v) -> append(k, v) }
            append("api_sig", apiSig)
            append("format", format)
        }))
    }

    // OAuth methods (kept for backward compatibility)
    suspend fun getToken() = runCatching {
        client.post {
            lastfmParams(
                method = "auth.getToken",
                apiKey = API_KEY,
                secret = SECRET
            )
        }.body<TokenResponse>()
    }

    suspend fun getSession(token: String) = runCatching {
        client.post {
            lastfmParams(
                method = "auth.getSession",
                apiKey = API_KEY,
                secret = SECRET,
                extra = mapOf("token" to token)
            )
        }.body<Authentication>()
    }

    // Mobile session authentication
    suspend fun getMobileSession(username: String, password: String) = runCatching {
        val response = client.post {
            lastfmParams(
                method = "auth.getMobileSession",
                apiKey = API_KEY,
                secret = SECRET,
                extra = mapOf("username" to username, "password" to password)
            )
            parameter("format", "json")
        }

        val responseText = response.bodyAsText()
        if (responseText.contains("\"error\"")) {
            val error = json.decodeFromString<LastFmError>(responseText)
            throw LastFmException(error.error, error.message)
        }
        json.decodeFromString<Authentication>(responseText)
    }

    /** An artist Last.fm considers similar, with a 0..1 similarity score. */
    data class SimilarArtist(val name: String, val match: Double)

    /**
     * Public, unsigned read call (needs only the API key, no secret and no login).
     * Used by Horizen's on-device recommendation engine to find artists close to your taste.
     */
    suspend fun getSimilarArtists(
        artist: String,
        limit: Int = 10,
    ): Result<List<SimilarArtist>> = runCatching {
        check(API_KEY.isNotEmpty()) { "Last.fm API key is not configured" }
        val text = client.get {
            userAgent("Horizen (personal build)")
            parameter("method", "artist.getsimilar")
            parameter("artist", artist)
            parameter("api_key", API_KEY)
            parameter("autocorrect", "1")
            parameter("limit", limit.toString())
            parameter("format", "json")
        }.bodyAsText()

        val root = json.parseToJsonElement(text).jsonObject
        root["error"]?.let {
            throw LastFmException(it.jsonPrimitive.contentOrNull?.toIntOrNull() ?: -1, root["message"]?.jsonPrimitive?.contentOrNull ?: "Last.fm error")
        }
        root["similarartists"]?.jsonObject?.get("artist")?.jsonArray
            ?.mapNotNull { element ->
                val obj: JsonObject = element.jsonObject
                val name = obj["name"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                SimilarArtist(name, obj["match"]?.jsonPrimitive?.doubleOrNull ?: 0.0)
            }
            .orEmpty()
    }

    /** A Last.fm tag with its popularity for an artist (0..100). */
    data class TopTag(val name: String, val count: Int)

    /** Public, unsigned read call: the genre/mood tags listeners use most for [artist]. */
    suspend fun getArtistTopTags(artist: String): Result<List<TopTag>> = runCatching {
        check(API_KEY.isNotEmpty()) { "Last.fm API key is not configured" }
        val text = client.get {
            userAgent("Horizen (personal build)")
            parameter("method", "artist.gettoptags")
            parameter("artist", artist)
            parameter("api_key", API_KEY)
            parameter("autocorrect", "1")
            parameter("format", "json")
        }.bodyAsText()

        val root = json.parseToJsonElement(text).jsonObject
        root["error"]?.let {
            throw LastFmException(it.jsonPrimitive.contentOrNull?.toIntOrNull() ?: -1, root["message"]?.jsonPrimitive?.contentOrNull ?: "Last.fm error")
        }
        root["toptags"]?.jsonObject?.get("tag")?.jsonArray
            ?.mapNotNull { element ->
                val obj: JsonObject = element.jsonObject
                val name = obj["name"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                TopTag(name, obj["count"]?.jsonPrimitive?.doubleOrNull?.toInt() ?: 0)
            }
            .orEmpty()
    }

    class LastFmException(val code: Int, override val message: String) : Exception(message) {
        override fun toString(): String = "LastFmException(code=$code, message=$message)"
    }

    suspend fun updateNowPlaying(
        artist: String, track: String,
        album: String? = null, trackNumber: Int? = null, duration: Int? = null
    ) = runCatching {
        client.post {
            lastfmParams(
                method = "track.updateNowPlaying",
                apiKey = API_KEY,
                secret = SECRET,
                sessionKey = sessionKey!!,
                extra = buildMap {
                    put("artist", artist)
                    put("track", track)
                    album?.let { put("album", it) }
                    trackNumber?.let { put("trackNumber", it.toString()) }
                    duration?.let { put("duration", it.toString()) }
                }
            )
            parameter("format", "json")
        }
    }

    suspend fun scrobble(
        artist: String, track: String, timestamp: Long,
        album: String? = null, trackNumber: Int? = null, duration: Int? = null
    ) = runCatching {
        client.post {
            lastfmParams(
                method = "track.scrobble",
                apiKey = API_KEY,
                secret = SECRET,
                sessionKey = sessionKey!!,
                extra = buildMap {
                    put("artist[0]", artist)
                    put("track[0]", track)
                    put("timestamp[0]", timestamp.toString())
                    album?.let { put("album[0]", it) }
                    trackNumber?.let { put("trackNumber[0]", it.toString()) }
                    duration?.let { put("duration[0]", it.toString()) }
                }
            )
            parameter("format", "json")
        }
    }


    suspend fun setLoveStatus(
        artist: String, track: String, love: Boolean
    ) = runCatching {
        val method = if (love) "track.love" else "track.unlove"
        client.post {
            lastfmParams(
                method = method,
                apiKey = API_KEY,
                secret = SECRET,
                sessionKey = sessionKey!!,
                extra = buildMap {
                    put("artist", artist)
                    put("track", track)
                }
            )
            parameter("format", "json")
        }
    }

    // API keys passed from the app module (loaded from BuildConfig/GitHub Secrets)
    private var API_KEY = ""
    private var SECRET = ""

    /**
     * Initialize LastFM with API credentials
     * @param apiKey LastFM API key
     * @param secret LastFM secret key
     */
    fun initialize(apiKey: String, secret: String) {
        API_KEY = apiKey
        SECRET = secret
    }

    fun isInitialized(): Boolean = API_KEY.isNotEmpty() && SECRET.isNotEmpty()

    const val DEFAULT_SCROBBLE_DELAY_PERCENT = 0.5f
    const val DEFAULT_SCROBBLE_MIN_SONG_DURATION = 30
    const val DEFAULT_SCROBBLE_DELAY_SECONDS = 180
}
