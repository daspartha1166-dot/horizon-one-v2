/**
 * Horizen — content-based similarity on genre/mood tag vectors.
 *
 * Every artist is described by a sparse vector of Last.fm tags (e.g. "bollywood" 1.0, "90s" 0.6).
 * Cosine similarity between two vectors tells how alike two artists sound, even if you never
 * played them in the same session. A listener's "taste vector" is the score-weighted sum of
 * the vectors of the artists they play most.
 */

package com.metrolist.music.recommendation

import kotlin.math.sqrt

internal object TagSimilarity {
    /** Cosine similarity of two sparse tag vectors, 0..1 (tag weights are never negative). */
    fun cosine(
        a: Map<String, Double>?,
        b: Map<String, Double>?,
    ): Double {
        if (a.isNullOrEmpty() || b.isNullOrEmpty()) return 0.0
        val (small, large) = if (a.size <= b.size) a to b else b to a
        var dot = 0.0
        for ((tag, weight) in small) {
            val other = large[tag] ?: continue
            dot += weight * other
        }
        if (dot == 0.0) return 0.0
        return dot / (norm(a) * norm(b))
    }

    /** Weighted sum of tag vectors, i.e. the listener's taste profile in tag space. */
    fun combine(parts: List<Pair<Map<String, Double>, Double>>): Map<String, Double> {
        val out = HashMap<String, Double>()
        for ((vector, weight) in parts) {
            for ((tag, value) in vector) out[tag] = (out[tag] ?: 0.0) + value * weight
        }
        return out
    }

    fun topTags(
        vector: Map<String, Double>,
        count: Int,
    ): List<String> = vector.entries.sortedByDescending { it.value }.take(count).map { it.key }

    private fun norm(v: Map<String, Double>): Double = sqrt(v.values.sumOf { it * it })
}
