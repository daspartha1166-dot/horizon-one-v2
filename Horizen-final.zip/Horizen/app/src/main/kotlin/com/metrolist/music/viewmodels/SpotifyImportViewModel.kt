/**
 * Horizen — drives the "Import Spotify history" screen.
 */

package com.metrolist.music.viewmodels

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.recommendation.spotify.ImportPhase
import com.metrolist.music.recommendation.spotify.ImportProgress
import com.metrolist.music.recommendation.spotify.SpotifyFileContents
import com.metrolist.music.recommendation.spotify.SpotifyHistoryImporter
import com.metrolist.music.recommendation.spotify.SpotifyHistoryParser
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.inject.Inject

@HiltViewModel
class SpotifyImportViewModel
@Inject
constructor(
    @ApplicationContext private val context: Context,
    private val importer: SpotifyHistoryImporter,
) : ViewModel() {
    private val _progress = MutableStateFlow(ImportProgress())
    val progress: StateFlow<ImportProgress> = _progress.asStateFlow()

    private var job: Job? = null

    val isRunning: Boolean
        get() = job?.isActive == true

    /** Reads the picked files (ZIP or JSON) and imports them. Does nothing if an import is already running. */
    fun start(uris: List<Uri>) {
        if (uris.isEmpty() || isRunning) return
        job =
            viewModelScope.launch {
                try {
                    _progress.value = ImportProgress(phase = ImportPhase.READING)
                    val contents = withContext(Dispatchers.IO) { readAll(uris) }
                    if (contents.plays.isEmpty() && contents.liked.isEmpty()) {
                        _progress.value =
                            ImportProgress(
                                phase = ImportPhase.FAILED,
                                message = "NO_DATA",
                            )
                        return@launch
                    }
                    importer.importHistory(contents.plays, contents.liked) { _progress.value = it }
                } catch (e: CancellationException) {
                    _progress.value = _progress.value.copy(phase = ImportPhase.CANCELLED)
                    throw e
                } catch (e: Exception) {
                    Timber.e(e, "Spotify import failed")
                    _progress.value = ImportProgress(phase = ImportPhase.FAILED, message = e.message)
                }
            }
    }

    fun cancel() {
        job?.cancel()
    }

    fun reset() {
        if (!isRunning) _progress.value = ImportProgress()
    }

    private fun readAll(uris: List<Uri>): SpotifyFileContents {
        val plays = ArrayList<com.metrolist.music.recommendation.spotify.SpotifyPlay>()
        val liked = ArrayList<com.metrolist.music.recommendation.spotify.SpotifyLikedTrack>()
        fun add(c: SpotifyFileContents) {
            plays += c.plays
            liked += c.liked
        }
        for (uri in uris) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val buffered = stream.buffered()
                    buffered.mark(4)
                    val magic = ByteArray(4)
                    val n = buffered.read(magic)
                    buffered.reset()
                    val isZip = n == 4 && magic[0] == 'P'.code.toByte() && magic[1] == 'K'.code.toByte()
                    if (isZip) readZip(buffered, ::add) else add(SpotifyHistoryParser.parse(buffered.readBytes().decodeToString()))
                }
            }.onFailure { Timber.w(it, "Could not read %s", uri) }
        }
        return SpotifyFileContents(plays = plays, liked = liked)
    }

    private fun readZip(
        input: InputStream,
        sink: (SpotifyFileContents) -> Unit,
    ) {
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && SpotifyHistoryParser.isRelevantFileName(entry.name)) {
                    sink(SpotifyHistoryParser.parse(zip.readBytes().decodeToString()))
                }
                zip.closeEntry()
            }
        }
    }
}
