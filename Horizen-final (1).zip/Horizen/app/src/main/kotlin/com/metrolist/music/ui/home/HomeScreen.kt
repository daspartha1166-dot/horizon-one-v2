/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.home

import androidx.annotation.StringRes
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.metrolist.music.R
import com.metrolist.music.db.entities.Song
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.recommendation.RecommendationMix
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.utils.resize
import com.metrolist.music.viewmodels.HomeViewModel
import com.metrolist.music.viewmodels.OfflineBackupViewModel
import java.time.LocalDateTime

/**
 * Home: greeting card, the Offline Backup banner (only while offline), recommendation mixes and quick picks.
 * Everything shown comes from [HomeViewModel] / [OfflineBackupViewModel]; this file only draws it.
 */
@Composable
fun HomeScreen(
    playerConnection: PlayerConnection?,
    modifier: Modifier = Modifier,
    homeViewModel: HomeViewModel = hiltViewModel(),
    backupViewModel: OfflineBackupViewModel = hiltViewModel(),
) {
    LaunchedEffect(Unit) { homeViewModel.loadHomeData() }

    val mixes by homeViewModel.recommendationMixes.collectAsStateWithLifecycle()
    val quickPicks by homeViewModel.quickPicks.collectAsStateWithLifecycle()
    val isLoading by homeViewModel.isLoading.collectAsStateWithLifecycle()
    val showBackup by backupViewModel.showOnHome.collectAsStateWithLifecycle()
    val backupSongs by backupViewModel.songs.collectAsStateWithLifecycle()
    val isOnline by backupViewModel.isOnline.collectAsStateWithLifecycle()

    // Mixes built from YouTube results cannot play without a network.
    val visibleMixes =
        remember(mixes, isOnline) {
            mixes.orEmpty().filter { isOnline || (it.songs.isNotEmpty() && it.remoteSongs.isEmpty()) }
        }
    val picks = remember(quickPicks) { quickPicks.orEmpty().take(10) }

    fun playSongs(
        title: String?,
        songs: List<Song>,
        startIndex: Int = 0,
    ) {
        playerConnection?.playQueue(ListQueue(title = title, items = songs.map { it.toMediaItem() }, startIndex = startIndex))
    }

    fun playMix(mix: RecommendationMix) {
        val items = mix.songs.map { it.toMediaItem() } + mix.remoteSongs.map { it.toMediaItem() }
        if (items.isNotEmpty()) playerConnection?.playQueue(ListQueue(title = mix.title, items = items))
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp, bottom = 24.dp),
    ) {
        item(key = "greeting") { GreetingCard() }

        if (showBackup && backupSongs.isNotEmpty()) {
            item(key = "backup") {
                OfflineBackupBanner(
                    songCount = backupSongs.size,
                    onPlay = { playSongs("Offline Backup", backupSongs) },
                    onSave = { backupViewModel.saveToLibrary() },
                )
            }
            itemsIndexed(backupSongs.take(5), key = { _, song -> "backup_" + song.id }) { index, song ->
                SongRow(song) { playSongs("Offline Backup", backupSongs, index) }
            }
        }

        if (visibleMixes.isNotEmpty()) {
            item(key = "mixes") {
                Column {
                    SectionTitle(stringResource(R.string.hz_made_for_you))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(visibleMixes, key = { _, mix -> mix.id }) { _, mix ->
                            MixCard(mix) { playMix(mix) }
                        }
                    }
                }
            }
        }

        if (picks.isNotEmpty()) {
            item(key = "picks_title") { SectionTitle(stringResource(R.string.hz_quick_picks)) }
            itemsIndexed(picks, key = { _, song -> "pick_" + song.id }) { index, song ->
                SongRow(song) { playSongs("Quick picks", picks, index) }
            }
        }

        if (visibleMixes.isEmpty() && picks.isEmpty() && !showBackup) {
            item(key = "empty") {
                Box(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp), contentAlignment = Alignment.Center) {
                    if (isLoading) {
                        CircularProgressIndicator(color = HorizenPalette.Accent, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                    } else {
                        Text(
                            text = stringResource(R.string.hz_play_a_few_songs_and_your_mixes_will_app),
                            style = TextStyle(color = HorizenPalette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center),
                        )
                    }
                }
            }
        }
    }
}

@StringRes
private fun greetingFor(hour: Int): Int =
    when (hour) {
        in 5..11 -> R.string.hz_good_morning
        in 12..16 -> R.string.hz_good_afternoon
        in 17..20 -> R.string.hz_good_evening
        else -> R.string.hz_good_night
    }

@Composable
private fun GreetingCard(modifier: Modifier = Modifier) {
    val greeting = stringResource(remember { greetingFor(LocalDateTime.now().hour) })
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier =
            modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(170.dp)
                .clip(shape)
                .border(1.dp, Color.White.copy(alpha = 0.18f), shape),
    ) {
        Image(
            painter = painterResource(R.drawable.horizen_mist_card),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Text(
            text = greeting,
            style = TextStyle(fontFamily = HorizenScript, fontSize = 38.sp, color = Color.White),
            modifier = Modifier.padding(start = 20.dp, top = 14.dp),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = TextStyle(fontFamily = HorizenScript, fontSize = 28.sp, color = Color.White),
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 10.dp),
    )
}

@Composable
private fun OfflineBackupBanner(
    songCount: Int,
    onPlay: () -> Unit,
    onSave: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .padding(horizontal = 16.dp, vertical = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(HorizenPalette.SurfaceHigh)
                .clickable(onClick = onPlay)
                .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(48.dp).clip(CircleShape).background(HorizenPalette.Accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(R.drawable.offline),
                contentDescription = null,
                tint = HorizenPalette.Background,
                modifier = Modifier.size(26.dp),
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.hz_offline_backup), style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold))
            Text(stringResource(R.string.hz_songs_ready_offline, songCount), style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp))
        }
        TextButton(onClick = onSave) { Text(stringResource(R.string.hz_save)) }
    }
}

@Composable
private fun MixCard(
    mix: RecommendationMix,
    onClick: () -> Unit,
) {
    Column(Modifier.width(150.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        AsyncImage(
            model = mix.artworkUrls.firstOrNull()?.resize(width = 300, height = 300),
            contentDescription = mix.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(150.dp).clip(RoundedCornerShape(16.dp)).background(HorizenPalette.MistDark),
        )
        Spacer(Modifier.height(8.dp))
        Text(mix.kind.label, style = TextStyle(color = HorizenPalette.Accent, fontSize = 10.sp, letterSpacing = 1.2.sp))
        Text(
            text = mix.title,
            style = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = mix.subtitle,
            style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun SongRow(
    song: Song,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AsyncImage(
            model = song.song.thumbnailUrl?.resize(width = 160, height = 160),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(HorizenPalette.MistDark),
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = song.song.title,
                style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = song.artists.joinToString { it.name },
                style = TextStyle(color = HorizenPalette.Muted, fontSize = 13.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
