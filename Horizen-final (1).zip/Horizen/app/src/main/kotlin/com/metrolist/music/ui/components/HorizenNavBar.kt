/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.metrolist.music.R
import com.metrolist.music.ui.theme.HorizenPalette

enum class HorizenTab(
    val label: String,
    @DrawableRes val icon: Int,
    @DrawableRes val selectedIcon: Int,
) {
    Home("Home", R.drawable.home_outlined, R.drawable.home_filled),
    Search("Search", R.drawable.search, R.drawable.search),
    Library("Library", R.drawable.library_music_outlined, R.drawable.library_music_filled),
    Profile("Profile", R.drawable.person, R.drawable.person),
    ;

    /** Navigation route of this tab. */
    val route: String get() = name.lowercase()
}

/** Flat grey bottom bar with four icons, as in the Horizen mockup. */
@Composable
fun HorizenNavBar(
    selected: HorizenTab,
    onSelect: (HorizenTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier =
            modifier
                .fillMaxWidth()
                .background(HorizenPalette.NavBar)
                .navigationBarsPadding()
                .height(64.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        HorizenTab.entries.forEach { tab ->
            val isSelected = tab == selected
            val alpha by animateFloatAsState(if (isSelected) 1f else 0.55f, tween(200), label = "navAlpha")
            Box(
                modifier =
                    Modifier
                        .weight(1f)
                        .height(64.dp)
                        .clickable { onSelect(tab) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(if (isSelected) tab.selectedIcon else tab.icon),
                    contentDescription = tab.label,
                    tint = HorizenPalette.OnBackground.copy(alpha = alpha),
                    modifier = Modifier.size(28.dp),
                )
            }
        }
    }
}
