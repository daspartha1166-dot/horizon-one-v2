/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.profile

import com.metrolist.music.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.recommendation.MusicLanguage
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.viewmodels.ProfileViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterGroup(
    label: String,
    content: @Composable () -> Unit,
) {
    androidx.compose.foundation.layout.Column(Modifier.padding(top = 10.dp)) {
        Text(label, style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp), modifier = Modifier.padding(bottom = 6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = TextStyle(color = Color.White, fontSize = 15.sp), modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Profile: Offline Backup switch and favourite languages (feeds the recommendation cold start). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    onOpenStats: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = hiltViewModel(),
) {
    val backupEnabled by viewModel.backupEnabled.collectAsStateWithLifecycle()
    val seed by viewModel.seed.collectAsStateWithLifecycle()
    val hideExplicit by viewModel.hideExplicit.collectAsStateWithLifecycle()
    val hideVideoSongs by viewModel.hideVideoSongs.collectAsStateWithLifecycle()
    val facets by viewModel.facets.collectAsStateWithLifecycle()
    val filter by viewModel.filter.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp, bottom = 24.dp),
    ) {
        item(key = "title") {
            Text(
                stringResource(R.string.hz_profile),
                style = TextStyle(fontFamily = HorizenScript, fontSize = 34.sp, color = Color.White),
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        item(key = "stats") {
            TextButton(onClick = onOpenStats, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) { Text(stringResource(R.string.hz_listening_stats)) }
        }
        item(key = "backup") {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.hz_offline_backup), style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold))
                    Text(
                        stringResource(R.string.hz_keep_recent_songs_and_your_queue_playabl),
                        style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp),
                    )
                }
                Switch(checked = backupEnabled, onCheckedChange = viewModel::setBackupEnabled)
            }
        }
        if (backupEnabled && (facets.moods.isNotEmpty() || facets.genres.isNotEmpty() || facets.artists.isNotEmpty())) {
            item(key = "filters") {
                androidx.compose.foundation.layout.Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            stringResource(R.string.hz_backup_filters),
                            style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.weight(1f),
                        )
                        if (!filter.isEmpty) TextButton(onClick = viewModel::clearFilter) { Text(stringResource(R.string.hz_clear)) }
                    }
                    FilterGroup(stringResource(R.string.hz_mood)) {
                        facets.moods.forEach { mood ->
                            FilterChip(
                                selected = mood in filter.moods,
                                onClick = { viewModel.toggleMood(mood) },
                                label = { Text(mood.name.lowercase().replaceFirstChar { it.uppercase() }) },
                            )
                        }
                    }
                    FilterGroup(stringResource(R.string.hz_genre)) {
                        facets.genres.forEach { genre ->
                            FilterChip(
                                selected = genre in filter.genres,
                                onClick = { viewModel.toggleGenre(genre) },
                                label = { Text(genre) },
                            )
                        }
                    }
                    FilterGroup(stringResource(R.string.hz_artist)) {
                        facets.artists.forEach { artist ->
                            FilterChip(
                                selected = artist.id in filter.artistIds,
                                onClick = { viewModel.toggleArtist(artist.id) },
                                label = { Text(artist.name) },
                            )
                        }
                    }
                }
            }
        }
        item(key = "content") {
            androidx.compose.foundation.layout.Column(Modifier.padding(16.dp)) {
                SettingSwitch(stringResource(R.string.hz_hide_explicit_songs), hideExplicit, viewModel::setHideExplicit)
                SettingSwitch(stringResource(R.string.hz_hide_video_songs), hideVideoSongs, viewModel::setHideVideoSongs)
            }
        }
        item(key = "languages") {
            androidx.compose.foundation.layout.Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.hz_music_languages), style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold))
                Text(
                    stringResource(R.string.hz_used_to_shape_your_first_recommendations),
                    style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp),
                    modifier = Modifier.padding(bottom = 10.dp),
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MusicLanguage.entries.forEach { language ->
                        FilterChip(
                            selected = language in seed.languages,
                            onClick = { viewModel.toggleLanguage(language) },
                            label = { Text(language.label) },
                        )
                    }
                }
            }
        }
    }
}
