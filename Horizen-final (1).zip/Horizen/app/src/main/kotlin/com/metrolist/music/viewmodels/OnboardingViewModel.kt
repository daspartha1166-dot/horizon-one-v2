/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.constants.OnboardingDoneKey
import com.metrolist.music.utils.safeDataStoreEdit
import com.metrolist.music.recommendation.MusicLanguage
import com.metrolist.music.recommendation.TasteSeed
import com.metrolist.music.recommendation.TasteSeedStore
import com.metrolist.music.utils.dataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** First-run onboarding: collects languages and favourite artists, then marks onboarding as done. */
@HiltViewModel
class OnboardingViewModel
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
        private val seedStore: TasteSeedStore,
    ) : ViewModel() {
        /** `null` until DataStore has been read, so the UI never flashes onboarding for returning users. */
        val done: StateFlow<Boolean?> =
            context.dataStore.data
                .map { prefs -> (prefs[OnboardingDoneKey] ?: false) as Boolean? }
                .stateIn(viewModelScope, SharingStarted.Eagerly, null)

        private val _languages = MutableStateFlow<Set<MusicLanguage>>(emptySet())
        val languages = _languages.asStateFlow()

        private val _artists = MutableStateFlow<List<String>>(emptyList())
        val artists = _artists.asStateFlow()

        fun toggleLanguage(language: MusicLanguage) {
            _languages.value = _languages.value.let { if (language in it) it - language else it + language }
        }

        fun addArtist(name: String) {
            val clean = name.trim()
            val current = _artists.value
            if (clean.isEmpty() || current.size >= TasteSeed.MAX_ARTISTS) return
            if (current.any { it.equals(clean, ignoreCase = true) }) return
            _artists.value = current + clean
        }

        fun removeArtist(name: String) {
            _artists.value = _artists.value - name
        }

        /** Saves the picks (skipping saves an empty seed) and never shows onboarding again. */
        fun finish() {
            viewModelScope.launch {
                seedStore.save(TasteSeed(languages = _languages.value, artistNames = _artists.value))
                context.safeDataStoreEdit { it[OnboardingDoneKey] = true }
            }
        }
    }
