/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import com.metrolist.music.db.entities.Song
import java.time.Duration
import java.time.LocalDateTime
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow

internal data class HistoryEntry(
    val songId: String,
    val timestamp: LocalDateTime,
)

/**
 * Pure selection logic for the Offline Backup playlist (no Android, no I/O), so it is unit-testable.
 *
 * Ranking: songs in the current queue come first (queue order), then recently and frequently
 * played songs. Only songs that can actually be played offline survive ([isAvailableOffline]).
 * Because the ranking is recomputed from live history it keeps adapting to what the user listens to.
 */
internal object OfflineBackupSelector {
    fun select(
        history: List<HistoryEntry>,
        queueSongIds: List<String>,
        songsById: Map<String, Song>,
        isAvailableOffline: (Song) -> Boolean,
        artistTags: (artistName: String) -> Map<String, Double>?,
        filter: OfflineBackupFilter,
        now: LocalDateTime,
        limit: Int = OfflineBackupConfig.MAX_SONGS,
    ): OfflineBackupSelection {
        val scores = scoreSongs(history, queueSongIds, now)

        val playable =
            scores.entries
                .sortedByDescending { it.value }
                .mapNotNull { songsById[it.key] }
                .filter(isAvailableOffline)

        val facets = buildFacets(playable, artistTags)
        val filtered = playable.filter { matches(it, filter, artistTags) }
        return OfflineBackupSelection(filtered.take(limit), facets)
    }

    internal fun scoreSongs(
        history: List<HistoryEntry>,
        queueSongIds: List<String>,
        now: LocalDateTime,
    ): Map<String, Double> {
        val scores = HashMap<String, Double>()

        val bySong = history.groupBy { it.songId }
        val maxCount = bySong.values.maxOfOrNull { it.size } ?: 0
        for ((songId, events) in bySong) {
            val latest = events.maxOf { it.timestamp }
            val ageDays = Duration.between(latest, now).toMinutes().coerceAtLeast(0) / (60.0 * 24.0)
            val recency = 0.5.pow(ageDays / OfflineBackupConfig.RECENCY_HALF_LIFE_DAYS)
            val frequency = if (maxCount > 0) ln(1.0 + events.size) / ln(1.0 + maxCount) else 0.0
            scores[songId] = OfflineBackupConfig.RECENCY_WEIGHT * recency + OfflineBackupConfig.FREQUENCY_WEIGHT * frequency
        }

        queueSongIds.distinct().forEachIndexed { index, songId ->
            val queueScore = OfflineBackupConfig.QUEUE_BASE_SCORE + 1.0 / (1.0 + index)
            scores[songId] = max(scores[songId] ?: 0.0, queueScore)
        }
        return scores
    }

    internal fun matches(
        song: Song,
        filter: OfflineBackupFilter,
        artistTags: (String) -> Map<String, Double>?,
    ): Boolean {
        if (filter.isEmpty) return true

        if (filter.artistIds.isNotEmpty() && song.artists.none { it.id in filter.artistIds }) return false

        if (filter.moods.isNotEmpty() || filter.genres.isNotEmpty()) {
            // Songs whose artists have no tag data yet cannot be classified, so they are left out
            // of a mood/genre view rather than guessed at.
            val tagList = song.artists.mapNotNull { artistTags(it.name.lowercase()) }
            if (filter.moods.isNotEmpty()) {
                val songMoods = tagList.flatMapTo(HashSet()) { MoodClassifier.moodsOf(it) }
                if (songMoods.none { it in filter.moods }) return false
            }
            if (filter.genres.isNotEmpty()) {
                val songGenres = tagList.flatMapTo(HashSet()) { MoodClassifier.genresOf(it).keys }
                if (songGenres.none { it in filter.genres }) return false
            }
        }
        return true
    }

    private fun buildFacets(
        songs: List<Song>,
        artistTags: (String) -> Map<String, Double>?,
    ): OfflineBackupFacets {
        val artists = songs.flatMap { it.artists }.distinctBy { it.id }.sortedBy { it.name.lowercase() }
        val moods = HashSet<Mood>()
        val genreWeight = HashMap<String, Double>()
        for (artist in artists) {
            val tags = artistTags(artist.name.lowercase()) ?: continue
            moods += MoodClassifier.moodsOf(tags)
            for ((genre, weight) in MoodClassifier.genresOf(tags)) {
                genreWeight[genre] = (genreWeight[genre] ?: 0.0) + weight
            }
        }
        val genres =
            genreWeight.entries
                .sortedByDescending { it.value }
                .take(OfflineBackupConfig.MAX_GENRE_FACETS)
                .map { it.key }
        return OfflineBackupFacets(artists, moods, genres)
    }
}
