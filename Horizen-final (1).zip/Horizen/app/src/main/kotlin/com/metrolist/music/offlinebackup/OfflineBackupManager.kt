/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.datastore.preferences.core.Preferences
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.ContentMetadata
import com.metrolist.music.constants.HideExplicitKey
import com.metrolist.music.constants.HideVideoSongsKey
import com.metrolist.music.constants.OfflineBackupArtistFilterKey
import com.metrolist.music.constants.OfflineBackupEnabledKey
import com.metrolist.music.constants.OfflineBackupGenreFilterKey
import com.metrolist.music.constants.OfflineBackupMoodFilterKey
import com.metrolist.music.constants.PersistentQueueKey
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.PlaylistEntity
import com.metrolist.music.db.entities.Song
import com.metrolist.music.di.ApplicationScope
import com.metrolist.music.di.PlayerCache
import com.metrolist.music.extensions.filterExplicit
import com.metrolist.music.extensions.filterVideoSongs
import com.metrolist.music.extensions.isInternetConnected
import com.metrolist.music.models.PersistQueue
import com.metrolist.music.playback.MusicService
import com.metrolist.music.recommendation.RecommendationEngine
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.safeDataStoreEdit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import java.io.ObjectInputStream
import java.time.LocalDateTime
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Offline Backup: an always-ready playlist for when the network disappears.
 *
 * - Built automatically from recently played songs plus the current queue, and kept up to date
 *   as the user listens (no manual downloads).
 * - Only includes songs already playable without network (player cache, downloads, local files),
 *   so it costs no extra storage.
 * - Can be narrowed by artist, mood and genre ([setFilter]); moods/genres come from Last.fm tags
 *   that are fetched while online and stored on disk ([ArtistTagStore]).
 * - [showOnHome] turns true when the device goes offline and there is something to play, so a UI
 *   can surface the playlist on the home screen. [saveToLibrary] pins it into the library.
 *
 * UI-agnostic: observe [songs], [selection], [filter], [showOnHome]; call [start] once.
 */
@OptIn(FlowPreview::class)
@Singleton
class OfflineBackupManager
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
        private val database: MusicDatabase,
        @PlayerCache private val playerCache: Cache,
        private val tagStore: ArtistTagStore,
        private val recommendationEngine: RecommendationEngine,
        @ApplicationScope private val scope: CoroutineScope,
    ) {
        private val started = AtomicBoolean(false)
        private val enriching = AtomicBoolean(false)
        private val attemptedTagArtists: MutableSet<String> = ConcurrentHashMap.newKeySet()
        private val tagVersion = MutableStateFlow(0)
        private val refreshRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

        private val _selection = MutableStateFlow(OfflineBackupSelection())

        /** Songs plus the artist/mood/genre choices available for filtering. */
        val selection: StateFlow<OfflineBackupSelection> = _selection

        /** The playlist, already filtered and ranked. */
        val songs: StateFlow<List<Song>> =
            _selection
                .map { it.songs }
                .stateIn(scope, SharingStarted.Eagerly, emptyList())

        /** True when the device has a validated internet connection (debounced against network switches). */
        val isOnline: StateFlow<Boolean> =
            connectivityFlow()
                .debounce(1_000)
                .stateIn(scope, SharingStarted.Eagerly, context.isInternetConnected())

        val enabled: StateFlow<Boolean> =
            context.dataStore.data
                .map { it[OfflineBackupEnabledKey] ?: true }
                .distinctUntilChanged()
                .stateIn(scope, SharingStarted.Eagerly, true)

        val filter: StateFlow<OfflineBackupFilter> =
            context.dataStore.data
                .map { it.toFilter() }
                .distinctUntilChanged()
                .stateIn(scope, SharingStarted.Eagerly, OfflineBackupFilter())

        /** Show the backup on the home screen: feature on, device offline, something playable. */
        val showOnHome: StateFlow<Boolean> =
            combine(enabled, isOnline, songs) { on, online, list -> on && !online && list.isNotEmpty() }
                .distinctUntilChanged()
                .stateIn(scope, SharingStarted.Eagerly, false)

        /** Begins keeping the playlist current. Safe to call repeatedly. */
        fun start() {
            if (!started.compareAndSet(false, true)) return
            scope.launch(Dispatchers.IO) {
                merge(
                    database.latestEvent().map { it?.event?.id }.distinctUntilChanged().map { },
                    filter.map { },
                    enabled.map { },
                    isOnline.map { },
                    tagVersion.map { },
                    refreshRequests,
                    ticker(),
                ).debounce(OfflineBackupConfig.REBUILD_DEBOUNCE_MS)
                    .collectLatest {
                        runCatching { rebuild() }.onFailure { Timber.w(it, "Offline backup rebuild failed") }
                    }
            }
        }

        /** Forces a rebuild, e.g. after the queue or cache changed. */
        fun refresh() {
            refreshRequests.tryEmit(Unit)
        }

        suspend fun setEnabled(value: Boolean) {
            context.safeDataStoreEdit { it[OfflineBackupEnabledKey] = value }
        }

        suspend fun setFilter(newFilter: OfflineBackupFilter) {
            context.safeDataStoreEdit { prefs ->
                prefs[OfflineBackupArtistFilterKey] = newFilter.artistIds
                prefs[OfflineBackupMoodFilterKey] = newFilter.moods.mapTo(HashSet()) { it.name }
                prefs[OfflineBackupGenreFilterKey] = newFilter.genres
            }
        }

        suspend fun clearFilter() = setFilter(OfflineBackupFilter())

        /**
         * Pins the current backup as a regular local playlist in the library (replacing its previous
         * contents). Returns the playlist id, or null when there is nothing to save.
         */
        suspend fun saveToLibrary(): String? {
            val current = songs.value
            if (current.isEmpty()) return null
            val playlistId = PlaylistEntity.OFFLINE_BACKUP_PLAYLIST_ID
            database.withTransaction {
                val now = LocalDateTime.now()
                val existing = playlist(playlistId).first()?.playlist
                if (existing == null) {
                    insert(
                        PlaylistEntity(
                            id = playlistId,
                            name = OfflineBackupConfig.SAVED_PLAYLIST_NAME,
                            isEditable = true,
                            bookmarkedAt = now,
                            lastUpdateTime = now,
                        ),
                    )
                } else {
                    update(existing.copy(bookmarkedAt = existing.bookmarkedAt ?: now, lastUpdateTime = now))
                }
                clearPlaylist(playlistId)
                playlist(playlistId).first()?.let { full ->
                    addSongsToPlaylist(full, current.map { it.id to null })
                }
            }
            return playlistId
        }

        // -----------------------------------------------------------------------------------------

        private suspend fun rebuild() {
            if (!enabled.value) {
                _selection.value = OfflineBackupSelection()
                return
            }
            val prefs = context.dataStore.data.first()
            val now = LocalDateTime.now()

            val events =
                database.recentEvents(
                    fromTimeStamp = now.minusDays(OfflineBackupConfig.HISTORY_DAYS),
                    limit = OfflineBackupConfig.MAX_EVENTS,
                )
            val queueIds = if (prefs[PersistentQueueKey] ?: true) readQueueSongIds() else emptyList()

            val ids = (events.map { it.songId } + queueIds).distinct()
            val songsById =
                ids
                    .chunked(SQLITE_ARG_CHUNK)
                    .flatMap { database.getSongsByIds(it) }
                    .filterExplicit(prefs[HideExplicitKey] ?: false)
                    .filterVideoSongs(prefs[HideVideoSongsKey] ?: false)
                    .associateBy { it.id }

            val result =
                OfflineBackupSelector.select(
                    history = events.map { HistoryEntry(it.songId, it.timestamp) },
                    queueSongIds = queueIds,
                    songsById = songsById,
                    isAvailableOffline = ::isAvailableOffline,
                    artistTags = tagStore::get,
                    filter = prefs.toFilter(),
                    now = now,
                )
            _selection.value = result

            if (isOnline.value) {
                enrichTags(result.facets.artists.map { it.name })
            }
        }

        private fun isAvailableOffline(song: Song): Boolean {
            val entity = song.song
            if (entity.isLocal || entity.isDownloaded) return true
            val length =
                song.format?.contentLength
                    ?: ContentMetadata
                        .getContentLength(playerCache.getContentMetadata(entity.id))
                        .takeIf { it > 0L }
                    ?: return false
            return playerCache.isCached(entity.id, 0, length)
        }

        /** Songs of the saved queue, current song first, then upcoming, then already played. */
        private fun readQueueSongIds(): List<String> {
            val file = context.filesDir.resolve(MusicService.PERSISTENT_QUEUE_FILE)
            if (!file.exists()) return emptyList()
            return runCatching {
                file.inputStream().use { input ->
                    ObjectInputStream(input).use { stream ->
                        val queue = stream.readObject() as PersistQueue
                        val ids = queue.items.map { it.id }
                        val start = queue.mediaItemIndex.coerceIn(0, (ids.size - 1).coerceAtLeast(0))
                        ids.drop(start) + ids.take(start)
                    }
                }
            }.getOrDefault(emptyList())
        }

        /** Downloads missing mood/genre tags in the background so filters also work once offline. */
        private fun enrichTags(artistNames: List<String>) {
            val missing =
                artistNames
                    .filter { name ->
                        val key = name.lowercase()
                        !tagStore.has(key) && key !in attemptedTagArtists
                    }.take(OfflineBackupConfig.TAG_ENRICH_BATCH)
            if (missing.isEmpty() || !enriching.compareAndSet(false, true)) return

            missing.forEach { attemptedTagArtists += it.lowercase() }
            scope.launch(Dispatchers.IO) {
                try {
                    val vectors =
                        withTimeoutOrNull(OfflineBackupConfig.TAG_ENRICH_TIMEOUT_MS) {
                            runCatching { recommendationEngine.tagVectorsFor(missing) }.getOrNull()
                        }
                    if (vectors != null && tagStore.putAll(vectors)) tagVersion.update { it + 1 }
                } finally {
                    enriching.set(false)
                }
            }
        }

        private fun ticker(): Flow<Unit> =
            flow {
                emit(Unit)
                while (true) {
                    delay(OfflineBackupConfig.REBUILD_TICK_MS)
                    emit(Unit)
                }
            }

        private fun connectivityFlow(): Flow<Boolean> =
            callbackFlow {
                val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                if (manager == null) {
                    trySend(true)
                    close()
                    return@callbackFlow
                }
                val callback =
                    object : ConnectivityManager.NetworkCallback() {
                        override fun onCapabilitiesChanged(
                            network: Network,
                            capabilities: NetworkCapabilities,
                        ) {
                            trySend(
                                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                            )
                        }

                        override fun onLost(network: Network) {
                            trySend(false)
                        }
                    }
                trySend(context.isInternetConnected())
                runCatching { manager.registerDefaultNetworkCallback(callback) }
                    .onFailure { Timber.w(it, "Could not watch connectivity") }
                awaitClose { runCatching { manager.unregisterNetworkCallback(callback) } }
            }.distinctUntilChanged()

        private fun Preferences.toFilter() =
            OfflineBackupFilter(
                artistIds = this[OfflineBackupArtistFilterKey].orEmpty(),
                moods = this[OfflineBackupMoodFilterKey].orEmpty().mapNotNull { runCatching { Mood.valueOf(it) }.getOrNull() }.toSet(),
                genres = this[OfflineBackupGenreFilterKey].orEmpty(),
            )

        private companion object {
            /** Stay well under SQLite's bound-variable limit for IN (...) queries. */
            const val SQLITE_ARG_CHUNK = 500
        }
    }
