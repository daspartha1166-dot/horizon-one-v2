/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.components

import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.metrolist.innertube.models.AlbumItem
import com.metrolist.innertube.models.ArtistItem
import com.metrolist.innertube.models.PlaylistItem
import com.metrolist.innertube.models.SongItem
import com.metrolist.innertube.models.YTItem
import com.metrolist.music.R
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.utils.resize

/** Back button + artwork + title + play button, shared by the album, artist and playlist pages. */
@Composable
fun DetailHeader(
    title: String,
    subtitle: String?,
    imageUrl: String?,
    onBack: () -> Unit,
    onPlay: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp)) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.arrow_back), contentDescription = stringResource(R.string.hz_back), tint = Color.White)
            }
        }
        AsyncImage(
            model = imageUrl?.resize(width = 600, height = 600),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(200.dp).clip(RoundedCornerShape(20.dp)).background(HorizenPalette.MistDark),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = title,
            style = TextStyle(fontFamily = HorizenScript, fontSize = 30.sp, color = Color.White, textAlign = TextAlign.Center),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        if (!subtitle.isNullOrBlank()) {
            Text(subtitle, style = TextStyle(color = HorizenPalette.Muted, fontSize = 13.sp), modifier = Modifier.padding(top = 4.dp))
        }
        if (onPlay != null) {
            Box(
                modifier =
                    Modifier
                        .padding(vertical = 16.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(HorizenPalette.Accent)
                        .clickable(onClick = onPlay)
                        .padding(horizontal = 32.dp, vertical = 12.dp),
            ) {
                Text(stringResource(R.string.hz_play), style = TextStyle(color = HorizenPalette.Background, fontSize = 15.sp, fontWeight = FontWeight.SemiBold))
            }
        }
    }
}

/** Row for any YouTube Music item; the callback matching the item's type is invoked on tap. */
@Composable
fun YtItemRow(
    item: YTItem,
    onSong: (SongItem) -> Unit,
    onAlbum: (AlbumItem) -> Unit,
    onArtist: (ArtistItem) -> Unit,
    onPlaylist: (PlaylistItem) -> Unit,
) {
    when (item) {
        is SongItem ->
            TrackRow(item.title, item.artists.joinToString { it.name }, item.thumbnail, onClick = { onSong(item) })
        is AlbumItem ->
            TrackRow(item.title, stringResource(R.string.hz_album_by, item.artists.orEmpty().joinToString { it.name }), item.thumbnail, onClick = { onAlbum(item) })
        is ArtistItem ->
            TrackRow(item.title, stringResource(R.string.hz_artist_label), item.thumbnail, onClick = { onArtist(item) })
        is PlaylistItem ->
            TrackRow(item.title, item.author?.name?.let { stringResource(R.string.hz_playlist_by, it) } ?: stringResource(R.string.hz_playlist_label), item.thumbnail, onClick = { onPlaylist(item) })
        else -> Unit
    }
}

/** Back button + title, for pages without artwork. */
@Composable
fun DetailTopBar(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onBack),
            contentAlignment = Alignment.Center,
        ) {
            Icon(painterResource(R.drawable.arrow_back), contentDescription = stringResource(R.string.hz_back), tint = Color.White)
        }
        Text(title, style = TextStyle(fontFamily = HorizenScript, fontSize = 30.sp, color = Color.White), modifier = Modifier.padding(start = 8.dp))
    }
}
