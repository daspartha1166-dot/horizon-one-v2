/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui

import android.net.Uri

/** Detail-page routes. Argument names match what the ViewModels read from SavedStateHandle. */
object Routes {
    const val ALBUM = "album/{albumId}"
    const val ARTIST = "artist/{artistId}"
    const val PLAYLIST = "playlist/{playlistId}"
    const val LOCAL_PLAYLIST = "localplaylist/{playlistId}"
    const val STATS = "stats"

    fun album(id: String) = "album/${Uri.encode(id)}"

    fun artist(id: String) = "artist/${Uri.encode(id)}"

    fun playlist(id: String) = "playlist/${Uri.encode(id)}"

    fun localPlaylist(id: String) = "localplaylist/${Uri.encode(id)}"
}
