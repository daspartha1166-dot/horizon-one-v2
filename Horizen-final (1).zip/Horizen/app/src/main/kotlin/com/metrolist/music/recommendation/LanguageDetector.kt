/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.recommendation

/** Languages the onboarding picker and the language filter understand. */
enum class MusicLanguage(
    val label: String,
    /** Words (matched on word boundaries, case-insensitive) that name the language or its film industry. */
    internal val keywords: List<String>,
) {
    HINDI("Hindi", listOf("hindi", "bollywood")),
    BENGALI("Bengali", listOf("bengali", "bangla", "rabindra sangeet", "baul")),
    PUNJABI("Punjabi", listOf("punjabi")),
    TAMIL("Tamil", listOf("tamil", "kollywood")),
    TELUGU("Telugu", listOf("telugu", "tollywood")),
    MALAYALAM("Malayalam", listOf("malayalam", "mollywood")),
    KANNADA("Kannada", listOf("kannada", "sandalwood")),
    MARATHI("Marathi", listOf("marathi")),
    BHOJPURI("Bhojpuri", listOf("bhojpuri")),
    HARYANVI("Haryanvi", listOf("haryanvi")),
    /** Never detected from text: "English" shows up in plenty of Hindi titles ("Lyrics & English"). */
    ENGLISH("English", emptyList()),
}

/**
 * Best-effort language guess from text (song title, artist names, genre tags).
 *
 * Native scripts are decisive. Latin-script text is only classified when it names a language
 * explicitly, because romanised Hindi cannot be told apart from English by spelling alone;
 * in every other case the answer is `null` ("don't know") and callers should let the song through.
 */
object LanguageDetector {
    private data class ScriptRange(
        val language: MusicLanguage,
        val range: IntRange,
    )

    private val scripts =
        listOf(
            ScriptRange(MusicLanguage.BENGALI, 0x0980..0x09FF),
            ScriptRange(MusicLanguage.PUNJABI, 0x0A00..0x0A7F),
            ScriptRange(MusicLanguage.TAMIL, 0x0B80..0x0BFF),
            ScriptRange(MusicLanguage.TELUGU, 0x0C00..0x0C7F),
            ScriptRange(MusicLanguage.KANNADA, 0x0C80..0x0CFF),
            ScriptRange(MusicLanguage.MALAYALAM, 0x0D00..0x0D7F),
            // Devanagari is shared by Hindi, Marathi, Bhojpuri…; Hindi is the default, keywords refine it.
            ScriptRange(MusicLanguage.HINDI, 0x0900..0x097F),
        )

    /** Specific regional names win over the generic "hindi/bollywood" when both appear. */
    private val keywordPriority =
        listOf(
            MusicLanguage.BHOJPURI,
            MusicLanguage.HARYANVI,
            MusicLanguage.MARATHI,
            MusicLanguage.BENGALI,
            MusicLanguage.PUNJABI,
            MusicLanguage.TAMIL,
            MusicLanguage.TELUGU,
            MusicLanguage.MALAYALAM,
            MusicLanguage.KANNADA,
            MusicLanguage.HINDI,
        )

    private val keywordRegex: Map<MusicLanguage, Regex> =
        MusicLanguage.entries.filter { it.keywords.isNotEmpty() }.associateWith { language ->
            Regex("\\b(" + language.keywords.joinToString("|") { Regex.escape(it) } + ")\\b", RegexOption.IGNORE_CASE)
        }

    fun detect(text: String?): MusicLanguage? {
        if (text.isNullOrBlank()) return null

        val scriptCounts = HashMap<MusicLanguage, Int>()
        for (ch in text) {
            val code = ch.code
            if (code < 0x0900) continue
            scripts.firstOrNull { code in it.range }?.let { scriptCounts[it.language] = (scriptCounts[it.language] ?: 0) + 1 }
        }
        val byScript = scriptCounts.maxByOrNull { it.value }?.key

        val byKeyword = keywordPriority.firstOrNull { keywordRegex.getValue(it).containsMatchIn(text) }

        return when {
            // Devanagari text that also names a more specific language (e.g. Marathi) → trust the name.
            byScript == MusicLanguage.HINDI && byKeyword != null -> byKeyword
            byScript != null -> byScript
            else -> byKeyword
        }
    }
}
