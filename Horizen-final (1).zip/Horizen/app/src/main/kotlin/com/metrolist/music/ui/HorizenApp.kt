/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.metrolist.music.ui.detail.AlbumScreen
import com.metrolist.music.ui.detail.ArtistScreen
import com.metrolist.music.ui.detail.LocalPlaylistScreen
import com.metrolist.music.ui.detail.PlaylistScreen
import com.metrolist.music.ui.stats.StatsScreen
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.ui.components.HorizenNavBar
import com.metrolist.music.ui.components.HorizenTab
import com.metrolist.music.ui.home.HomeScreen
import com.metrolist.music.ui.library.LibraryScreen
import com.metrolist.music.ui.onboarding.OnboardingScreen
import com.metrolist.music.ui.profile.ProfileScreen
import com.metrolist.music.viewmodels.OnboardingViewModel
import com.metrolist.music.ui.search.SearchScreen
import com.metrolist.music.ui.player.FullPlayer
import com.metrolist.music.ui.player.MiniPlayer
import com.metrolist.music.ui.splash.SPLASH_DURATION_MS
import com.metrolist.music.ui.splash.SplashScreen
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow

/** Root of the Horizen UI: splash, then the tabbed shell with the mini/full player. */
@Composable
fun HorizenApp(playerConnection: PlayerConnection?) {
    HorizenTheme {
        var showSplash by rememberSaveable { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            if (showSplash) {
                delay(SPLASH_DURATION_MS)
                showSplash = false
            }
        }
        Box(Modifier.fillMaxSize().background(HorizenPalette.Background)) {
            Crossfade(targetState = showSplash, animationSpec = tween(500), label = "splash") { splash ->
                if (splash) SplashScreen() else Gate(playerConnection)
            }
        }
    }
}

/** Shows onboarding on first run, the main shell afterwards (nothing while the flag is loading). */
@Composable
private fun Gate(playerConnection: PlayerConnection?, viewModel: OnboardingViewModel = hiltViewModel()) {
    val done by viewModel.done.collectAsStateWithLifecycle()
    when (done) {
        null -> Box(Modifier.fillMaxSize())
        false -> OnboardingScreen(viewModel = viewModel)
        true -> MainShell(playerConnection)
    }
}

@Composable
private fun MainShell(playerConnection: PlayerConnection?) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    var tab by rememberSaveable { mutableStateOf(HorizenTab.Home) }
    // Detail pages keep the tab they were opened from highlighted.
    val currentRoute = backStackEntry?.destination?.route
    LaunchedEffect(currentRoute) {
        HorizenTab.entries.firstOrNull { it.route == currentRoute }?.let { tab = it }
    }
    fun openTab(target: HorizenTab) {
        navController.navigate(target.route) {
            popUpTo(HorizenTab.Home.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    var playerExpanded by rememberSaveable { mutableStateOf(false) }

    val metadataFlow = remember(playerConnection) { playerConnection?.mediaMetadata ?: MutableStateFlow<MediaMetadata?>(null) }
    val playingFlow = remember(playerConnection) { playerConnection?.isEffectivelyPlaying ?: MutableStateFlow(false) }
    val mediaMetadata by metadataFlow.collectAsStateWithLifecycle()
    val isPlaying by playingFlow.collectAsStateWithLifecycle()

    val hasTrack = playerConnection != null && mediaMetadata != null
    LaunchedEffect(hasTrack) { if (!hasTrack) playerExpanded = false }
    BackHandler(enabled = playerExpanded) { playerExpanded = false }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                NavHost(
                    navController = navController,
                    startDestination = HorizenTab.Home.route,
                    enterTransition = { fadeIn(tween(220)) },
                    exitTransition = { fadeOut(tween(140)) },
                    popEnterTransition = { fadeIn(tween(220)) },
                    popExitTransition = { fadeOut(tween(140)) },
                ) {
                    composable(HorizenTab.Home.route) { HomeScreen(playerConnection) }
                    composable(HorizenTab.Search.route) {
                        SearchScreen(
                            playerConnection = playerConnection,
                            onOpenAlbum = { navController.navigate(Routes.album(it)) },
                            onOpenArtist = { navController.navigate(Routes.artist(it)) },
                            onOpenPlaylist = { navController.navigate(Routes.playlist(it)) },
                        )
                    }
                    composable(HorizenTab.Library.route) {
                        LibraryScreen(playerConnection, onOpenPlaylist = { navController.navigate(Routes.localPlaylist(it)) })
                    }
                    composable(HorizenTab.Profile.route) { ProfileScreen(onOpenStats = { navController.navigate(Routes.STATS) }) }
                    composable(Routes.STATS) { StatsScreen(playerConnection, onBack = { navController.popBackStack() }) }
                    composable(Routes.LOCAL_PLAYLIST) { LocalPlaylistScreen(playerConnection, onBack = { navController.popBackStack() }) }
                    composable(Routes.ALBUM) { AlbumScreen(playerConnection, onBack = { navController.popBackStack() }) }
                    composable(Routes.ARTIST) {
                        ArtistScreen(
                            playerConnection = playerConnection,
                            onBack = { navController.popBackStack() },
                            onOpenAlbum = { navController.navigate(Routes.album(it)) },
                            onOpenArtist = { navController.navigate(Routes.artist(it)) },
                            onOpenPlaylist = { navController.navigate(Routes.playlist(it)) },
                        )
                    }
                    composable(Routes.PLAYLIST) { PlaylistScreen(playerConnection, onBack = { navController.popBackStack() }) }
                }
            }
            val current = mediaMetadata
            if (playerConnection != null && current != null) {
                MiniPlayer(
                    playerConnection = playerConnection,
                    mediaMetadata = current,
                    isPlaying = isPlaying,
                    onExpand = { playerExpanded = true },
                )
            }
            HorizenNavBar(selected = tab, onSelect = ::openTab)
        }

        AnimatedVisibility(
            visible = playerExpanded && hasTrack,
            enter = slideInVertically(tween(320)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200)),
        ) {
            val current = mediaMetadata
            if (playerConnection != null && current != null) {
                FullPlayer(
                    playerConnection = playerConnection,
                    mediaMetadata = current,
                    isPlaying = isPlaying,
                    onCollapse = { playerExpanded = false },
                )
            }
        }
    }
}
