/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.detail

import com.metrolist.music.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.DetailHeader
import com.metrolist.music.ui.components.TrackRow
import com.metrolist.music.viewmodels.LocalPlaylistViewModel

/** A playlist stored on this device. The ViewModel reads `playlistId` from the navigation arguments. */
@Composable
fun LocalPlaylistScreen(
    playerConnection: PlayerConnection?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LocalPlaylistViewModel = hiltViewModel(),
) {
    val playlist by viewModel.playlist.collectAsStateWithLifecycle()
    val entries by viewModel.playlistSongs.collectAsStateWithLifecycle()
    val songs = entries.map { it.song }

    fun play(startIndex: Int) {
        playerConnection?.playQueue(
            ListQueue(title = playlist?.playlist?.name, items = songs.map { it.toMediaItem() }, startIndex = startIndex),
        )
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            DetailHeader(
                title = playlist?.playlist?.name.orEmpty(),
                subtitle = stringResource(R.string.hz_songs_count, songs.size),
                imageUrl = playlist?.playlist?.thumbnailUrl ?: songs.firstOrNull()?.song?.thumbnailUrl,
                onBack = onBack,
                onPlay = if (songs.isNotEmpty()) ({ play(0) }) else null,
            )
        }
        itemsIndexed(songs, key = { index, s -> "${index}_${s.id}" }) { index, song ->
            TrackRow(song.song.title, song.artists.joinToString { it.name }, song.song.thumbnailUrl, onClick = { play(index) })
        }
    }
}
