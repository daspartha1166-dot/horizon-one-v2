/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.player

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.media3.common.C
import com.metrolist.music.playback.PlayerConnection
import kotlinx.coroutines.delay

/** Current playback position and total length in milliseconds (0 when unknown). */
data class PlaybackProgress(
    val position: Long = 0L,
    val duration: Long = 0L,
) {
    val fraction: Float
        get() = if (duration > 0L) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
}

/** Polls the player; ExoPlayer offers no flow for the position. */
@Composable
fun rememberPlaybackProgress(
    playerConnection: PlayerConnection,
    isPlaying: Boolean,
): State<PlaybackProgress> =
    produceState(PlaybackProgress(), playerConnection, isPlaying) {
        while (true) {
            val player = runCatching { playerConnection.player }.getOrNull()
            val duration = player?.duration?.takeIf { it != C.TIME_UNSET && it > 0L } ?: 0L
            value = PlaybackProgress(player?.currentPosition ?: 0L, duration)
            delay(if (isPlaying) 500L else 1000L)
        }
    }

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
