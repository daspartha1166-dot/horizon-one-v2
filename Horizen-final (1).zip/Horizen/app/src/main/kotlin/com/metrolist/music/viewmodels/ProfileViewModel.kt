/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.constants.HideExplicitKey
import com.metrolist.music.constants.HideVideoSongsKey
import com.metrolist.music.offlinebackup.Mood
import com.metrolist.music.offlinebackup.OfflineBackupFacets
import com.metrolist.music.offlinebackup.OfflineBackupFilter
import com.metrolist.music.offlinebackup.OfflineBackupManager
import com.metrolist.music.recommendation.MusicLanguage
import com.metrolist.music.recommendation.TasteSeed
import com.metrolist.music.recommendation.TasteSeedStore
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.safeDataStoreEdit
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Profile settings: Offline Backup switch and the cold-start taste preferences (languages). */
@HiltViewModel
class ProfileViewModel
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
        private val backupManager: OfflineBackupManager,
        private val seedStore: TasteSeedStore,
    ) : ViewModel() {
        val backupEnabled: StateFlow<Boolean> = backupManager.enabled

        val seed: StateFlow<TasteSeed> =
            seedStore.seed.stateIn(viewModelScope, SharingStarted.Eagerly, TasteSeed.EMPTY)

        /** Artists, moods and genres present in the current backup, i.e. the filters worth offering. */
        val facets: StateFlow<OfflineBackupFacets> =
            backupManager.selection
                .map { it.facets }
                .stateIn(viewModelScope, SharingStarted.Eagerly, OfflineBackupFacets())

        val filter: StateFlow<OfflineBackupFilter> = backupManager.filter

        fun toggleMood(mood: Mood) = updateFilter { it.copy(moods = it.moods.toggle(mood)) }

        fun toggleGenre(genre: String) = updateFilter { it.copy(genres = it.genres.toggle(genre)) }

        fun toggleArtist(artistId: String) = updateFilter { it.copy(artistIds = it.artistIds.toggle(artistId)) }

        fun clearFilter() {
            viewModelScope.launch { backupManager.clearFilter() }
        }

        private fun updateFilter(transform: (OfflineBackupFilter) -> OfflineBackupFilter) {
            val next = transform(backupManager.filter.value)
            viewModelScope.launch { backupManager.setFilter(next) }
        }

        private fun <T> Set<T>.toggle(item: T): Set<T> = if (item in this) this - item else this + item

        val hideExplicit: StateFlow<Boolean> =
            context.dataStore.data
                .map { it[HideExplicitKey] ?: false }
                .stateIn(viewModelScope, SharingStarted.Eagerly, false)

        val hideVideoSongs: StateFlow<Boolean> =
            context.dataStore.data
                .map { it[HideVideoSongsKey] ?: false }
                .stateIn(viewModelScope, SharingStarted.Eagerly, false)

        fun setHideExplicit(value: Boolean) {
            viewModelScope.launch { context.safeDataStoreEdit { it[HideExplicitKey] = value } }
        }

        fun setHideVideoSongs(value: Boolean) {
            viewModelScope.launch { context.safeDataStoreEdit { it[HideVideoSongsKey] = value } }
        }

        fun setBackupEnabled(value: Boolean) {
            viewModelScope.launch { backupManager.setEnabled(value) }
        }

        fun toggleLanguage(language: MusicLanguage) {
            val current = seed.value
            val languages = if (language in current.languages) current.languages - language else current.languages + language
            viewModelScope.launch { seedStore.save(current.copy(languages = languages)) }
        }
    }
