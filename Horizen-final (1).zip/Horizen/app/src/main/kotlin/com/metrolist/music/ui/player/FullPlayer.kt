/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.player

import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import coil3.compose.AsyncImage
import com.metrolist.music.R
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.utils.resize

/** Full-screen player: artwork, seek bar and transport controls. */
@Composable
fun FullPlayer(
    playerConnection: PlayerConnection,
    mediaMetadata: MediaMetadata,
    isPlaying: Boolean,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val song by playerConnection.currentSong.collectAsStateWithLifecycle()
    val shuffle by playerConnection.shuffleModeEnabled.collectAsStateWithLifecycle()
    val repeatMode by playerConnection.repeatMode.collectAsStateWithLifecycle()
    val queueTitle by playerConnection.queueTitle.collectAsStateWithLifecycle()
    val progress by rememberPlaybackProgress(playerConnection, isPlaying)

    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val maxValue = progress.duration.coerceAtLeast(1L).toFloat()
    val sliderValue = if (dragging) dragValue else progress.position.toFloat().coerceIn(0f, maxValue)
    val liked = song?.song?.liked == true

    Box(modifier.fillMaxSize().background(HorizenPalette.Background).clickable(enabled = false) {}) {
        // Soft misty header that melts into the background.
        Image(
            painter = painterResource(R.drawable.horizen_mist_card),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(380.dp).alpha(0.35f),
        )
        Box(
            Modifier.fillMaxWidth().height(380.dp).background(
                Brush.verticalGradient(listOf(Color.Transparent, HorizenPalette.Background)),
            ),
        )

        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        painter = painterResource(R.drawable.expand_more),
                        contentDescription = stringResource(R.string.hz_close_player),
                        tint = HorizenPalette.OnBackground,
                        modifier = Modifier.size(32.dp),
                    )
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.hz_playing_from), style = TextStyle(color = HorizenPalette.Muted, fontSize = 10.sp, letterSpacing = 1.5.sp))
                    Text(
                        text = queueTitle ?: stringResource(R.string.hz_your_queue),
                        style = TextStyle(color = HorizenPalette.OnBackground, fontSize = 13.sp, fontWeight = FontWeight.Medium),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.size(48.dp))
            }

            Spacer(Modifier.height(16.dp))
            AsyncImage(
                model = mediaMetadata.thumbnailUrl?.resize(width = 800, height = 800),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(28.dp))
                        .background(HorizenPalette.MistDark),
            )

            Spacer(Modifier.height(28.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = mediaMetadata.title,
                        style = TextStyle(color = HorizenPalette.OnBackground, fontSize = 24.sp, fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = mediaMetadata.artists.joinToString { it.name },
                        style = TextStyle(color = HorizenPalette.Muted, fontSize = 16.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = { playerConnection.toggleLike() }) {
                    Icon(
                        painter = painterResource(if (liked) R.drawable.favorite else R.drawable.favorite_border),
                        contentDescription = if (liked) stringResource(R.string.hz_unlike) else stringResource(R.string.hz_like),
                        tint = if (liked) HorizenPalette.Accent else HorizenPalette.OnBackground,
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Slider(
                value = sliderValue,
                onValueChange = {
                    dragging = true
                    dragValue = it
                },
                onValueChangeFinished = {
                    playerConnection.seekTo(dragValue.toLong())
                    dragging = false
                },
                valueRange = 0f..maxValue,
                colors =
                    SliderDefaults.colors(
                        thumbColor = HorizenPalette.Accent,
                        activeTrackColor = HorizenPalette.Accent,
                        inactiveTrackColor = HorizenPalette.MistDark,
                    ),
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                Text(formatTime(sliderValue.toLong()), style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp))
                Spacer(Modifier.weight(1f))
                Text(formatTime(progress.duration), style = TextStyle(color = HorizenPalette.Muted, fontSize = 12.sp))
            }

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
            ) {
                IconButton(onClick = { runCatching { playerConnection.player.shuffleModeEnabled = !shuffle } }) {
                    Icon(
                        painter = painterResource(if (shuffle) R.drawable.shuffle_on else R.drawable.shuffle),
                        contentDescription = stringResource(R.string.hz_shuffle),
                        tint = if (shuffle) HorizenPalette.Accent else HorizenPalette.OnBackground,
                    )
                }
                IconButton(onClick = { playerConnection.seekToPrevious() }) {
                    Icon(
                        painter = painterResource(R.drawable.skip_previous),
                        contentDescription = stringResource(R.string.hz_previous),
                        tint = HorizenPalette.OnBackground,
                        modifier = Modifier.size(36.dp),
                    )
                }
                Box(
                    modifier =
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(HorizenPalette.Accent)
                            .clickable { playerConnection.togglePlayPause() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(if (isPlaying) R.drawable.pause else R.drawable.play),
                        contentDescription = if (isPlaying) stringResource(R.string.hz_pause) else stringResource(R.string.hz_play),
                        tint = HorizenPalette.Background,
                        modifier = Modifier.size(36.dp),
                    )
                }
                IconButton(onClick = { playerConnection.seekToNext() }) {
                    Icon(
                        painter = painterResource(R.drawable.skip_next),
                        contentDescription = stringResource(R.string.hz_next),
                        tint = HorizenPalette.OnBackground,
                        modifier = Modifier.size(36.dp),
                    )
                }
                IconButton(
                    onClick = {
                        runCatching {
                            playerConnection.player.repeatMode =
                                when (repeatMode) {
                                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                    else -> Player.REPEAT_MODE_OFF
                                }
                        }
                    },
                ) {
                    Icon(
                        painter =
                            painterResource(
                                when (repeatMode) {
                                    Player.REPEAT_MODE_ALL -> R.drawable.repeat_on
                                    Player.REPEAT_MODE_ONE -> R.drawable.repeat_one_on
                                    else -> R.drawable.repeat
                                },
                            ),
                        contentDescription = stringResource(R.string.hz_repeat),
                        tint = if (repeatMode == Player.REPEAT_MODE_OFF) HorizenPalette.OnBackground else HorizenPalette.Accent,
                    )
                }
            }
        }
    }
}
