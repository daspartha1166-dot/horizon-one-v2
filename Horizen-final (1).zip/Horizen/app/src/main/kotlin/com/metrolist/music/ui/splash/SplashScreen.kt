/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import kotlinx.coroutines.launch

const val SPLASH_DURATION_MS = 1800L

/** App-open screen: misty night sky with the Horizen wordmark fading in. */
@Composable
fun SplashScreen(modifier: Modifier = Modifier) {
    val textAlpha = remember { Animatable(0f) }
    val textScale = remember { Animatable(0.94f) }
    val mistAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { mistAlpha.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        launch { textAlpha.animateTo(1f, tween(1000, delayMillis = 250, easing = FastOutSlowInEasing)) }
        textScale.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
    }

    Box(modifier.fillMaxSize().background(HorizenPalette.Background)) {
        Image(
            painter = painterResource(R.drawable.horizen_mist),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.5f).alpha(mistAlpha.value),
        )
        // Melt the texture into the solid background so there is no visible edge.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    colorStops =
                        arrayOf(
                            0f to Color.Transparent,
                            0.5f to HorizenPalette.Background,
                            1f to HorizenPalette.Background,
                        ),
                ),
            ),
        )
        Text(
            text = "Horizen",
            style = TextStyle(fontFamily = HorizenScript, fontSize = 68.sp, color = Color.White),
            modifier =
                Modifier
                    .align(Alignment.Center)
                    .graphicsLayer {
                        alpha = textAlpha.value
                        scaleX = textScale.value
                        scaleY = textScale.value
                    },
        )
    }
}
