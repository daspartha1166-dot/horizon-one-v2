/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.recommendation

/**
 * What a new listener tells the app at onboarding: favourite languages and artists.
 *
 * It solves the cold-start problem in two ways:
 *  - [allows] filters out songs in a language the listener did not pick;
 *  - [artistBoost] gives the picked artists a head start in the taste profile, fading away
 *    as real listening history accumulates.
 */
data class TasteSeed(
    val languages: Set<MusicLanguage> = emptySet(),
    val artistNames: List<String> = emptyList(),
) {
    val isEmpty: Boolean get() = languages.isEmpty() && artistNames.isEmpty()

    /**
     * True when a song with this [text] (title + artists) and optional genre [tagNames] may be recommended.
     * Songs whose language cannot be determined are let through rather than guessed at.
     */
    fun allows(
        text: String,
        tagNames: Collection<String> = emptyList(),
    ): Boolean {
        if (languages.isEmpty()) return true
        val language =
            LanguageDetector.detect(text)
                ?: LanguageDetector.detect(tagNames.joinToString(" "))
                ?: return true
        return language in languages
    }

    fun isSeedArtist(name: String): Boolean = artistNames.any { it.equals(name, ignoreCase = true) }

    /** Extra affinity for a picked artist; shrinks as the number of real listening [events] grows. */
    fun artistBoost(events: Int): Double = SEED_ARTIST_BOOST / (1.0 + events.coerceAtLeast(0).toDouble() / SEED_FADE_EVENTS)

    companion object {
        val EMPTY = TasteSeed()

        /** Roughly the affinity of a few well-liked songs. */
        const val SEED_ARTIST_BOOST = 3.0

        /** After this many real plays the boost has halved. */
        const val SEED_FADE_EVENTS = 200.0
        const val MAX_ARTISTS = 10
    }
}
