/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.offlinebackup.OfflineBackupManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Thin UI-facing wrapper around [OfflineBackupManager]. */
@HiltViewModel
class OfflineBackupViewModel
    @Inject
    constructor(
        private val manager: OfflineBackupManager,
    ) : ViewModel() {
        val songs = manager.songs
        val showOnHome = manager.showOnHome
        val isOnline = manager.isOnline

        fun saveToLibrary() {
            viewModelScope.launch { manager.saveToLibrary() }
        }
    }
