/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Disk-backed cache of artist genre/mood tag vectors (lowercase artist name → tag → weight).
 *
 * Tags can only be downloaded while online, but moods and genres have to be usable offline,
 * so whatever was fetched is persisted here.
 */
@Singleton
class ArtistTagStore
    @Inject
    constructor(
        @ApplicationContext context: Context,
    ) {
        private val file = File(context.filesDir, OfflineBackupConfig.TAGS_FILE)
        private val tags = ConcurrentHashMap<String, Map<String, Double>>()

        @Volatile private var loaded = false

        fun get(lowercaseArtistName: String): Map<String, Double>? {
            ensureLoaded()
            return tags[lowercaseArtistName]
        }

        fun has(lowercaseArtistName: String): Boolean = get(lowercaseArtistName) != null

        /** Stores [vectors] (keys are lowercased) and flushes to disk. Returns true if anything changed. */
        @Synchronized
        fun putAll(vectors: Map<String, Map<String, Double>>): Boolean {
            ensureLoaded()
            var changed = false
            for ((name, vector) in vectors) {
                val key = name.lowercase()
                if (vector.isNotEmpty() && tags[key] != vector) {
                    tags[key] = vector
                    changed = true
                }
            }
            if (changed) persist()
            return changed
        }

        @Synchronized
        private fun ensureLoaded() {
            if (loaded) return
            loaded = true
            if (!file.exists()) return
            runCatching {
                val root = JSONObject(file.readText())
                for (artist in root.keys()) {
                    val vector = root.getJSONObject(artist)
                    tags[artist] = vector.keys().asSequence().associateWith { vector.getDouble(it) }
                }
            }.onFailure { Timber.w(it, "Could not read artist tag store; starting empty") }
        }

        private fun persist() {
            runCatching {
                val root = JSONObject()
                for ((artist, vector) in tags) {
                    root.put(artist, JSONObject(vector as Map<*, *>))
                }
                // Write-then-rename so a crash never leaves a half-written file behind.
                val tmp = File(file.parentFile, file.name + ".tmp")
                tmp.writeText(root.toString())
                if (!tmp.renameTo(file)) {
                    file.writeText(root.toString())
                    tmp.delete()
                }
            }.onFailure { Timber.w(it, "Could not write artist tag store") }
        }
    }
