/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

/** Turns Last.fm tag vectors (tag → weight 0..1) into moods and genres. */
internal object MoodClassifier {
    /** Words that double as a mood hint and a genre; these stay in the genre list. */
    private val genreLike =
        setOf("rock", "metal", "punk", "edm", "dance", "club", "ambient", "acoustic", "instrumental", "lofi", "lo-fi", "ballad")

    /** Tags that say nothing about the music itself. */
    private val noiseTags =
        setOf("seen live", "favorites", "favourites", "favorite", "favourite", "awesome", "good", "best", "love at first listen", "all")

    private fun words(tag: String): List<String> = tag.lowercase().split(' ', '-', '_').filter { it.isNotBlank() }

    private fun moodOfTag(tag: String): Set<Mood> {
        val lower = tag.lowercase()
        val tagWords = words(lower)
        return Mood.entries
            .filter { mood -> lower in mood.tokens || tagWords.any { it in mood.tokens } }
            .toSet()
    }

    fun isMoodTag(tag: String): Boolean = moodOfTag(tag).isNotEmpty()

    /** Moods whose summed tag weight reaches [OfflineBackupConfig.MOOD_MIN_SCORE]. */
    fun moodsOf(tags: Map<String, Double>?): Set<Mood> {
        if (tags.isNullOrEmpty()) return emptySet()
        val scores = HashMap<Mood, Double>()
        for ((tag, weight) in tags) {
            for (mood in moodOfTag(tag)) scores[mood] = (scores[mood] ?: 0.0) + weight
        }
        return scores.filterValues { it >= OfflineBackupConfig.MOOD_MIN_SCORE }.keys
    }

    /** Genre tags (strong enough, not a mood word, not noise), lowercase tag → weight. */
    fun genresOf(tags: Map<String, Double>?): Map<String, Double> {
        if (tags.isNullOrEmpty()) return emptyMap()
        return tags
            .filter { (tag, weight) ->
                val lower = tag.lowercase()
                weight >= OfflineBackupConfig.MIN_GENRE_WEIGHT && lower !in noiseTags && (lower in genreLike || !isMoodTag(lower))
            }.mapKeys { it.key.lowercase() }
    }
}
