/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.detail

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.innertube.models.SongItem
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.DetailHeader
import com.metrolist.music.ui.components.YtItemRow
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.viewmodels.ArtistViewModel

/** Artist page built from the YouTube Music artist sections (songs, albums, related artists...). */
@Composable
fun ArtistScreen(
    playerConnection: PlayerConnection?,
    onBack: () -> Unit,
    onOpenAlbum: (String) -> Unit,
    onOpenArtist: (String) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ArtistViewModel = hiltViewModel(),
) {
    val library by viewModel.libraryArtist.collectAsStateWithLifecycle(initialValue = null)
    val page = viewModel.artistPage
    val sections = page?.sections.orEmpty()
    val topSongs = sections.flatMap { it.items }.filterIsInstance<SongItem>()

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            DetailHeader(
                title = page?.artist?.title ?: library?.artist?.name.orEmpty(),
                subtitle = page?.monthlyListenerCount ?: page?.subscriberCountText,
                imageUrl = page?.artist?.thumbnail ?: library?.artist?.thumbnailUrl,
                onBack = onBack,
                onPlay =
                    if (topSongs.isNotEmpty()) {
                        { playerConnection?.playQueue(ListQueue(title = page?.artist?.title, items = topSongs.map { it.toMediaItem() })) }
                    } else {
                        null
                    },
            )
        }
        sections.forEach { section ->
            item(key = "t_" + section.title) {
                Text(
                    section.title,
                    style = TextStyle(fontFamily = HorizenScript, fontSize = 24.sp, color = Color.White),
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp),
                )
            }
            items(section.items.take(8), key = { section.title + "_" + it.id }) { item ->
                YtItemRow(
                    item = item,
                    onSong = { song -> playerConnection?.playQueue(ListQueue(title = song.title, items = listOf(song.toMediaItem()))) },
                    onAlbum = { onOpenAlbum(it.browseId) },
                    onArtist = { onOpenArtist(it.id) },
                    onPlaylist = { onOpenPlaylist(it.id) },
                )
            }
        }
    }
}
