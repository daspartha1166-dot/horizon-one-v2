/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.stats

import com.metrolist.music.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.constants.OptionStats
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.DetailTopBar
import com.metrolist.music.ui.components.TrackRow
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.viewmodels.StatsViewModel

/** Most played songs and artists for a chosen period. */
@Composable
fun StatsScreen(
    playerConnection: PlayerConnection?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: StatsViewModel = hiltViewModel(),
) {
    val option by viewModel.selectedOption.collectAsStateWithLifecycle()
    val songs by viewModel.mostPlayedSongs.collectAsStateWithLifecycle()
    val artists by viewModel.mostPlayedArtists.collectAsStateWithLifecycle()
    val topSongs = songs.take(20)

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "bar") { DetailTopBar(title = stringResource(R.string.hz_your_stats), onBack = onBack) }
        item(key = "period") {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OptionStats.entries.forEach { entry ->
                    FilterChip(
                        selected = option == entry,
                        onClick = {
                            viewModel.indexChips.value = 0
                            viewModel.selectedOption.value = entry
                        },
                        label = { Text(entry.name.lowercase().replaceFirstChar { it.uppercase() }) },
                    )
                }
            }
        }
        item(key = "songs_title") { StatsTitle(stringResource(R.string.hz_top_songs)) }
        itemsIndexed(topSongs, key = { index, s -> "song_${index}_${s.id}" }) { index, song ->
            TrackRow(
                title = "${index + 1}. ${song.song.title}",
                subtitle = song.artists.joinToString { it.name },
                thumbnailUrl = song.song.thumbnailUrl,
                onClick = {
                    playerConnection?.playQueue(ListQueue(title = "Top songs", items = topSongs.map { it.toMediaItem() }, startIndex = index))
                },
            )
        }
        item(key = "artists_title") { StatsTitle(stringResource(R.string.hz_top_artists)) }
        itemsIndexed(artists.take(10), key = { index, a -> "artist_${index}_${a.id}" }) { index, artist ->
            TrackRow(
                title = "${index + 1}. ${artist.artist.name}",
                subtitle = stringResource(R.string.hz_songs_count, artist.songCount),
                thumbnailUrl = artist.artist.thumbnailUrl,
                onClick = {},
            )
        }
    }
}

@Composable
private fun StatsTitle(text: String) {
    Text(
        text,
        style = TextStyle(fontFamily = HorizenScript, fontSize = 24.sp, color = Color.White),
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp),
    )
}
