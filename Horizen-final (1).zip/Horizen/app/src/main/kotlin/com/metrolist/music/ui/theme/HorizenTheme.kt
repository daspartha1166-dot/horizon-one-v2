/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** Colours sampled from the Horizen design mockups. */
object HorizenPalette {
    val Background = Color(0xFF000014)
    val Surface = Color(0xFF0A0F22)
    val SurfaceHigh = Color(0xFF151C36)
    val NavBar = Color(0xFF424242)
    val MistDark = Color(0xFF222E46)
    val MistLight = Color(0xFF8692A2)
    val Accent = Color(0xFFB9C6DA)
    val OnBackground = Color.White
    val Muted = Color(0xFF9AA4B5)
}

/**
 * Script face used for the wordmark, greetings and section titles.
 *
 * Android's built-in `cursive` family is used until a font file is bundled. To use a specific
 * face (e.g. Great Vibes or Sacramento, both free), put the .ttf in `res/font/` and change this to
 * `FontFamily(Font(R.font.your_font))`. Bengali text falls back to the system font automatically.
 */
val HorizenScript: FontFamily = FontFamily.Cursive

private val HorizenColorScheme =
    darkColorScheme(
        primary = HorizenPalette.Accent,
        onPrimary = HorizenPalette.Background,
        secondary = HorizenPalette.MistLight,
        onSecondary = HorizenPalette.Background,
        background = HorizenPalette.Background,
        onBackground = HorizenPalette.OnBackground,
        surface = HorizenPalette.Surface,
        onSurface = HorizenPalette.OnBackground,
        surfaceVariant = HorizenPalette.SurfaceHigh,
        onSurfaceVariant = HorizenPalette.Muted,
        outline = HorizenPalette.MistLight,
    )

/** Horizen is a dark-only design, so the scheme does not follow the system theme. */
@Composable
fun HorizenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HorizenColorScheme,
        typography = Typography(),
        content = content,
    )
}
