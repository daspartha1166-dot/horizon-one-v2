/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.search

import com.metrolist.music.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.YtItemRow
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.viewmodels.OnlineSearchSuggestionViewModel

/** Search: a text field backed by [OnlineSearchSuggestionViewModel]; song results are tappable to play. */
@Composable
fun SearchScreen(
    playerConnection: PlayerConnection?,
    onOpenAlbum: (String) -> Unit,
    onOpenArtist: (String) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: OnlineSearchSuggestionViewModel = hiltViewModel(),
) {
    val query by viewModel.query.collectAsStateWithLifecycle()
    val state by viewModel.viewState.collectAsStateWithLifecycle()
    val results = state.items

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp, bottom = 24.dp),
    ) {
        item(key = "title") {
            Text(
                stringResource(R.string.hz_search),
                style = TextStyle(fontFamily = HorizenScript, fontSize = 34.sp, color = Color.White),
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        item(key = "field") {
            Box(
                modifier =
                    Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(HorizenPalette.SurfaceHigh)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (query.isEmpty()) {
                    Text(stringResource(R.string.hz_songs_artists_albums), style = TextStyle(color = HorizenPalette.Muted, fontSize = 15.sp))
                }
                BasicTextField(
                    value = query,
                    onValueChange = { viewModel.query.value = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(HorizenPalette.Accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        itemsIndexed(results, key = { index, it -> "${index}_${it.id}" }) { _, result ->
            YtItemRow(
                item = result,
                onSong = { song -> playerConnection?.playQueue(ListQueue(title = song.title, items = listOf(song.toMediaItem()))) },
                onAlbum = { onOpenAlbum(it.browseId) },
                onArtist = { onOpenArtist(it.id) },
                onPlaylist = { onOpenPlaylist(it.id) },
            )
        }
        if (query.isNotBlank() && results.isEmpty()) {
            items(state.suggestions, key = { "s_$it" }) { suggestion ->
                Text(
                    text = suggestion,
                    style = TextStyle(color = HorizenPalette.Muted, fontSize = 15.sp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                )
            }
        }
    }
}
