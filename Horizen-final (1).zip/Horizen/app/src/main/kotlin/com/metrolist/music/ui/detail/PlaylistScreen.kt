/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.detail

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.DetailHeader
import com.metrolist.music.ui.components.TrackRow
import com.metrolist.music.viewmodels.OnlinePlaylistViewModel

/** Online playlist page. The ViewModel reads `playlistId` from the navigation arguments. */
@Composable
fun PlaylistScreen(
    playerConnection: PlayerConnection?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: OnlinePlaylistViewModel = hiltViewModel(),
) {
    val playlist by viewModel.playlist.collectAsStateWithLifecycle()
    val songs by viewModel.playlistSongs.collectAsStateWithLifecycle()

    fun play(startIndex: Int) {
        playerConnection?.playQueue(
            ListQueue(title = playlist?.title, items = songs.map { it.toMediaItem() }, startIndex = startIndex),
        )
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            DetailHeader(
                title = playlist?.title.orEmpty(),
                subtitle = playlist?.author?.name,
                imageUrl = playlist?.thumbnail,
                onBack = onBack,
                onPlay = if (songs.isNotEmpty()) ({ play(0) }) else null,
            )
        }
        itemsIndexed(songs, key = { index, s -> s.id + "_" + index }) { index, song ->
            TrackRow(song.title, song.artists.joinToString { it.name }, song.thumbnail, onClick = { play(index) })
        }
    }
}
