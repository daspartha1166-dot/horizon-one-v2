/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.detail

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.DetailHeader
import com.metrolist.music.ui.components.TrackRow
import com.metrolist.music.viewmodels.AlbumViewModel

/** Album page. The ViewModel reads `albumId` from the navigation arguments. */
@Composable
fun AlbumScreen(
    playerConnection: PlayerConnection?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AlbumViewModel = hiltViewModel(),
) {
    val album by viewModel.albumWithSongs.collectAsStateWithLifecycle()
    val data = album ?: return

    fun play(startIndex: Int) {
        playerConnection?.playQueue(
            ListQueue(title = data.album.title, items = data.songs.map { it.toMediaItem() }, startIndex = startIndex),
        )
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            DetailHeader(
                title = data.album.title,
                subtitle = data.artists.joinToString { it.name },
                imageUrl = data.album.thumbnailUrl,
                onBack = onBack,
                onPlay = if (data.songs.isNotEmpty()) ({ play(0) }) else null,
            )
        }
        itemsIndexed(data.songs, key = { _, s -> s.id }) { index, song ->
            TrackRow(song.song.title, song.artists.joinToString { it.name }, song.song.thumbnailUrl, onClick = { play(index) })
        }
    }
}
