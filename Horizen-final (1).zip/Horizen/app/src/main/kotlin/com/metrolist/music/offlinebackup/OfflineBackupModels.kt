/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import com.metrolist.music.db.entities.ArtistEntity
import com.metrolist.music.db.entities.Song

/** Tunables for the Offline Backup playlist. */
object OfflineBackupConfig {
    /** Maximum number of songs in the generated playlist. */
    const val MAX_SONGS = 100

    /** How far back the listening history is looked at. */
    const val HISTORY_DAYS = 30L
    const val MAX_EVENTS = 1500

    /** Recency half-life: a song heard this many days ago counts half as much as one heard now. */
    const val RECENCY_HALF_LIFE_DAYS = 7.0
    const val RECENCY_WEIGHT = 0.6
    const val FREQUENCY_WEIGHT = 0.4

    /** Queue songs always rank above history-only songs (score > 1.0), earlier queue slots first. */
    const val QUEUE_BASE_SCORE = 1.0

    /** Minimum summed tag weight for an artist to be labelled with a mood. */
    const val MOOD_MIN_SCORE = 0.3

    /** Minimum Last.fm tag weight (0..1) for a tag to count as one of an artist's genres. */
    const val MIN_GENRE_WEIGHT = 0.3
    const val MAX_GENRE_FACETS = 12

    /** Max artists whose tags are fetched in one enrichment pass while online. */
    const val TAG_ENRICH_BATCH = 30
    const val TAG_ENRICH_TIMEOUT_MS = 12_000L

    /** Playlist rebuild debounce and safety ticker (queue changes are only visible on disk). */
    const val REBUILD_DEBOUNCE_MS = 600L
    const val REBUILD_TICK_MS = 2 * 60 * 1000L

    const val SAVED_PLAYLIST_NAME = "Offline Backup"
    const val TAGS_FILE = "offline_backup_tags.json"
}

/** Moods the playlist can be filtered by. [tokens] are matched against Last.fm tag words. */
enum class Mood(
    val tokens: Set<String>,
) {
    ENERGETIC(setOf("energetic", "dance", "party", "workout", "upbeat", "edm", "club", "hype", "rock", "metal", "punk", "gym")),
    PEACEFUL(setOf("chill", "chillout", "relax", "relaxing", "calm", "ambient", "acoustic", "instrumental", "soft", "sleep", "lofi", "lo-fi", "meditation", "soothing", "peaceful")),
    ROMANTIC(setOf("romantic", "love", "romance", "ballad", "sensual", "lovesong", "lovesongs")),
    SAD(setOf("sad", "melancholy", "melancholic", "heartbreak", "depressing", "emotional", "sadness", "breakup")),
    HAPPY(setOf("happy", "feelgood", "fun", "cheerful", "summer", "joyful", "feel-good")),
}

/**
 * User-chosen narrowing of the backup playlist. Values inside one group are OR-ed
 * (any selected mood), the groups themselves are AND-ed.
 */
data class OfflineBackupFilter(
    val artistIds: Set<String> = emptySet(),
    val moods: Set<Mood> = emptySet(),
    val genres: Set<String> = emptySet(),
) {
    val isEmpty: Boolean get() = artistIds.isEmpty() && moods.isEmpty() && genres.isEmpty()
}

/** Artists, moods and genres present among the playable songs, i.e. the choices worth offering. */
data class OfflineBackupFacets(
    val artists: List<ArtistEntity> = emptyList(),
    val moods: Set<Mood> = emptySet(),
    val genres: List<String> = emptyList(),
)

data class OfflineBackupSelection(
    val songs: List<Song> = emptyList(),
    val facets: OfflineBackupFacets = OfflineBackupFacets(),
)
