/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.recommendation

import android.content.Context
import com.metrolist.music.constants.TasteSeedArtistsKey
import com.metrolist.music.constants.TasteSeedLanguagesKey
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.safeDataStoreEdit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Persists the onboarding [TasteSeed] in DataStore. */
@Singleton
class TasteSeedStore
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
    ) {
        val seed: Flow<TasteSeed> =
            context.dataStore.data
                .map { prefs ->
                    TasteSeed(
                        languages =
                            prefs[TasteSeedLanguagesKey]
                                .orEmpty()
                                .mapNotNull { runCatching { MusicLanguage.valueOf(it) }.getOrNull() }
                                .toSet(),
                        // Newline-joined to keep the order the listener picked them in.
                        artistNames = prefs[TasteSeedArtistsKey].orEmpty().split('\n').filter { it.isNotBlank() },
                    )
                }.distinctUntilChanged()

        suspend fun load(): TasteSeed = seed.first()

        suspend fun save(newSeed: TasteSeed) {
            context.safeDataStoreEdit { prefs ->
                prefs[TasteSeedLanguagesKey] = newSeed.languages.mapTo(HashSet()) { it.name }
                prefs[TasteSeedArtistsKey] =
                    newSeed.artistNames
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .distinctBy { it.lowercase() }
                        .take(TasteSeed.MAX_ARTISTS)
                        .joinToString("\n")
            }
        }

        suspend fun clear() = save(TasteSeed.EMPTY)
    }
