/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.wrapped

sealed class WrappedScreenType {
    object Welcome : WrappedScreenType()

    object MinutesTease : WrappedScreenType()

    object MinutesReveal : WrappedScreenType()

    object TotalSongs : WrappedScreenType()

    object TopSongReveal : WrappedScreenType()

    object Top5Songs : WrappedScreenType()

    object TotalAlbums : WrappedScreenType()

    object TopAlbumReveal : WrappedScreenType()

    object Top5Albums : WrappedScreenType()

    object TotalArtists : WrappedScreenType()

    object TopArtistReveal : WrappedScreenType()

    object Top5Artists : WrappedScreenType()

    object Playlist : WrappedScreenType()

    object Conclusion : WrappedScreenType()
}
