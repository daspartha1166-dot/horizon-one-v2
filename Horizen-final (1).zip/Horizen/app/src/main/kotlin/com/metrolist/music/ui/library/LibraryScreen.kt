/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.library

import androidx.annotation.StringRes
import com.metrolist.music.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.db.entities.Song
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.PlayerConnection
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.components.TrackRow
import com.metrolist.music.ui.theme.HorizenPalette
import com.metrolist.music.ui.theme.HorizenScript
import com.metrolist.music.viewmodels.HistoryViewModel
import com.metrolist.music.viewmodels.LibraryExtrasViewModel
import com.metrolist.music.viewmodels.LibrarySongsViewModel
import com.metrolist.music.viewmodels.PlaylistsViewModel

private enum class LibrarySection(@StringRes val labelRes: Int) {
    Liked(R.string.hz_liked),
    Downloaded(R.string.hz_downloaded),
    Playlists(R.string.hz_playlists),
    History(R.string.hz_history),
}

/** Library: liked, downloaded and history songs plus local playlists. */
@Composable
fun LibraryScreen(
    playerConnection: PlayerConnection?,
    onOpenPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibrarySongsViewModel = hiltViewModel(),
    historyViewModel: HistoryViewModel = hiltViewModel(),
    extrasViewModel: LibraryExtrasViewModel = hiltViewModel(),
    playlistsViewModel: PlaylistsViewModel = hiltViewModel(),
) {
    val liked by viewModel.allSongs.collectAsStateWithLifecycle()
    val history by historyViewModel.events.collectAsStateWithLifecycle()
    val downloaded by extrasViewModel.downloaded.collectAsStateWithLifecycle()
    val playlists by playlistsViewModel.allPlaylists.collectAsStateWithLifecycle()
    val historySongs = remember(history) { history.values.flatten().map { it.song } }

    var section by rememberSaveable { mutableStateOf(LibrarySection.Liked) }
    var creating by rememberSaveable { mutableStateOf(false) }
    val queueTitle = stringResource(section.labelRes)

    val songs: List<Song> =
        when (section) {
            LibrarySection.Liked -> liked
            LibrarySection.Downloaded -> downloaded
            LibrarySection.History -> historySongs
            LibrarySection.Playlists -> emptyList()
        }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 12.dp, bottom = 24.dp),
    ) {
        item(key = "title") {
            Text(
                stringResource(R.string.hz_library),
                style = TextStyle(fontFamily = HorizenScript, fontSize = 34.sp, color = Color.White),
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
            )
        }
        item(key = "sections") {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LibrarySection.entries.forEach { entry ->
                    FilterChip(selected = section == entry, onClick = { section = entry }, label = { Text(stringResource(entry.labelRes)) })
                }
            }
        }

        if (section == LibrarySection.Playlists) {
            item(key = "new_playlist") {
                TextButton(onClick = { creating = true }, modifier = Modifier.padding(horizontal = 8.dp)) { Text(stringResource(R.string.hz_new_playlist)) }
            }
            if (playlists.isEmpty()) {
                item(key = "empty_playlists") { EmptyHint(stringResource(R.string.hz_create_playlist_hint)) }
            }
            itemsIndexed(playlists, key = { _, p -> p.playlist.id }) { _, playlist ->
                TrackRow(
                    title = playlist.playlist.name,
                    subtitle = stringResource(R.string.hz_songs_count, playlist.songCount),
                    thumbnailUrl = playlist.playlist.thumbnailUrl ?: playlist.songThumbnails.firstOrNull { it != null },
                    onClick = { onOpenPlaylist(playlist.playlist.id) },
                )
            }
        } else {
            if (songs.isEmpty()) {
                item(key = "empty") {
                    EmptyHint(
                        when (section) {
                            LibrarySection.Downloaded -> stringResource(R.string.hz_downloaded_songs_will_appear_here)
                            LibrarySection.History -> stringResource(R.string.hz_songs_you_play_will_appear_here)
                            else -> stringResource(R.string.hz_songs_you_like_will_appear_here)
                        },
                    )
                }
            }
            itemsIndexed(songs, key = { index, s -> "${index}_${s.id}" }) { index, song ->
                TrackRow(
                    title = song.song.title,
                    subtitle = song.artists.joinToString { it.name },
                    thumbnailUrl = song.song.thumbnailUrl,
                    onClick = {
                        playerConnection?.playQueue(
                            ListQueue(title = queueTitle, items = songs.map { it.toMediaItem() }, startIndex = index),
                        )
                    },
                )
            }
        }
    }

    if (creating) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { creating = false },
            title = { Text(stringResource(R.string.hz_new_playlist)) },
            text = { TextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text(stringResource(R.string.hz_name)) }) },
            confirmButton = {
                TextButton(
                    onClick = {
                        extrasViewModel.createPlaylist(name)
                        creating = false
                    },
                    enabled = name.isNotBlank(),
                ) { Text(stringResource(R.string.hz_create)) }
            },
            dismissButton = { TextButton(onClick = { creating = false }) { Text(stringResource(R.string.hz_cancel)) } },
        )
    }
}

@Composable
private fun EmptyHint(text: String) {
    Text(text, style = TextStyle(color = HorizenPalette.Muted, fontSize = 14.sp), modifier = Modifier.padding(16.dp))
}
