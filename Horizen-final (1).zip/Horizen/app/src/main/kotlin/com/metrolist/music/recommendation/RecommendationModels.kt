/**
 * Horizen — on-device recommendation engine: public models.
 */

package com.metrolist.music.recommendation

import androidx.compose.runtime.Immutable
import com.metrolist.music.db.entities.Song
import com.metrolist.music.models.MediaMetadata

/** The flavour of a generated mix. Drives the label shown on its card. */
enum class MixKind(val label: String) {
    MADE_FOR_YOU("MADE FOR YOU"),
    DAILY_MIX("DAILY MIX"),
    TIME_OF_DAY("RIGHT NOW"),
    REDISCOVER("REDISCOVER"),
    DISCOVER("DISCOVER"),
    SIMILAR("FANS ALSO LIKE"),
    STARTER("START HERE"),
}

/** A ready-to-play, ordered set of songs generated from the listener's own history. */
@Immutable
data class RecommendationMix(
    val id: String,
    val kind: MixKind,
    val title: String,
    val subtitle: String,
    val songs: List<Song>,
    /** Songs not yet in the local database (e.g. from Last.fm similar artists); played straight from YouTube Music. */
    val remoteSongs: List<MediaMetadata> = emptyList(),
) {
    /** Up to four distinct album arts used to build the card collage. */
    val artworkUrls: List<String>
        get() = (songs.mapNotNull { it.song.thumbnailUrl } + remoteSongs.mapNotNull { it.thumbnailUrl })
            .distinct()
            .take(4)
}

/** Part of the day a listening session belongs to. */
enum class TimeBucket(val mixTitle: String, val mixSubtitle: String) {
    MORNING("Morning Boost", "Songs you love to start the day with"),
    AFTERNOON("Afternoon Flow", "What you usually play midday"),
    EVENING("Evening Wind-down", "Your evening favourites"),
    NIGHT("Late Night", "What you reach for after dark"),
    ;

    companion object {
        fun of(hour: Int): TimeBucket =
            when (hour) {
                in 5..11 -> MORNING
                in 12..16 -> AFTERNOON
                in 17..21 -> EVENING
                else -> NIGHT
            }
    }
}
