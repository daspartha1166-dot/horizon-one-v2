/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.metrolist.music.constants.SongSortType
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.PlaylistEntity
import com.metrolist.music.db.entities.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/** Library extras the stock ViewModels do not expose directly: downloaded songs and playlist creation. */
@HiltViewModel
class LibraryExtrasViewModel
    @Inject
    constructor(
        private val database: MusicDatabase,
    ) : ViewModel() {
        val downloaded: StateFlow<List<Song>> =
            database
                .downloadedSongs(SongSortType.CREATE_DATE, true)
                .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

        fun createPlaylist(name: String) {
            val clean = name.trim()
            if (clean.isEmpty()) return
            database.query { insert(PlaylistEntity(name = clean)) }
        }
    }
