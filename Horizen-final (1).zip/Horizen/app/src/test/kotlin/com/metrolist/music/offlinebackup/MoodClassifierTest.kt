/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodClassifierTest {
    @Test
    fun `strong mood tags are recognised`() {
        val moods = MoodClassifier.moodsOf(mapOf("chill" to 0.7, "love songs" to 0.5, "pop" to 1.0))
        assertEquals(setOf(Mood.PEACEFUL, Mood.ROMANTIC), moods)
    }

    @Test
    fun `weak mood tags below the threshold are ignored`() {
        assertTrue(MoodClassifier.moodsOf(mapOf("sad" to 0.1)).isEmpty())
    }

    @Test
    fun `several weak tags of one mood add up`() {
        assertEquals(setOf(Mood.SAD), MoodClassifier.moodsOf(mapOf("sad" to 0.2, "heartbreak" to 0.2)))
    }

    @Test
    fun `empty or null tags give no mood`() {
        assertTrue(MoodClassifier.moodsOf(null).isEmpty())
        assertTrue(MoodClassifier.moodsOf(emptyMap()).isEmpty())
    }

    @Test
    fun `genres drop mood words and noise but keep genre-like words`() {
        val genres =
            MoodClassifier.genresOf(
                mapOf("rock" to 0.9, "chill" to 0.9, "seen live" to 1.0, "Bollywood" to 0.8, "indie" to 0.1),
            )
        assertEquals(setOf("rock", "bollywood"), genres.keys)
    }
}
