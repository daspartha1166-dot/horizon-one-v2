/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.offlinebackup

import com.metrolist.music.db.entities.ArtistEntity
import com.metrolist.music.db.entities.Song
import com.metrolist.music.db.entities.SongEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime

class OfflineBackupSelectorTest {
    private val now = LocalDateTime.of(2026, 10, 30, 12, 0)

    private val arijit = ArtistEntity(id = "a1", name = "Arijit Singh")
    private val metallica = ArtistEntity(id = "a2", name = "Metallica")
    private val enya = ArtistEntity(id = "a3", name = "Enya")

    private fun song(
        id: String,
        artist: ArtistEntity,
    ) = Song(song = SongEntity(id = id, title = id), artists = listOf(artist))

    private val songs =
        listOf(
            song("s1", arijit),
            song("s2", metallica),
            song("s3", enya),
            song("s4", arijit),
        ).associateBy { it.id }

    private val tags: Map<String, Map<String, Double>> =
        mapOf(
            "arijit singh" to mapOf("bollywood" to 1.0, "romantic" to 0.8, "sad" to 0.4),
            "metallica" to mapOf("metal" to 1.0, "rock" to 0.7, "seen live" to 0.9),
            "enya" to mapOf("ambient" to 0.9, "chill" to 0.8, "new age" to 0.6),
        )

    private fun select(
        history: List<HistoryEntry> = emptyList(),
        queue: List<String> = emptyList(),
        available: (Song) -> Boolean = { true },
        filter: OfflineBackupFilter = OfflineBackupFilter(),
        limit: Int = 100,
    ) = OfflineBackupSelector.select(history, queue, songs, available, { tags[it] }, filter, now, limit)

    private fun ids(selection: OfflineBackupSelection) = selection.songs.map { it.id }

    @Test
    fun `recent songs rank above old ones`() {
        val history =
            listOf(
                HistoryEntry("s1", now.minusDays(25)),
                HistoryEntry("s2", now.minusHours(1)),
            )
        assertEquals(listOf("s2", "s1"), ids(select(history)))
    }

    @Test
    fun `frequently played song beats a single play of equal age`() {
        val history =
            listOf(
                HistoryEntry("s1", now.minusDays(1)),
                HistoryEntry("s2", now.minusDays(1)),
                HistoryEntry("s2", now.minusDays(1)),
                HistoryEntry("s2", now.minusDays(1)),
            )
        assertEquals(listOf("s2", "s1"), ids(select(history)))
    }

    @Test
    fun `queue songs come first in queue order`() {
        val history = listOf(HistoryEntry("s1", now.minusMinutes(1)))
        assertEquals(listOf("s3", "s4", "s1"), ids(select(history, queue = listOf("s3", "s4"))))
    }

    @Test
    fun `songs that are not available offline are dropped`() {
        val history = listOf(HistoryEntry("s1", now), HistoryEntry("s2", now))
        assertEquals(listOf("s2"), ids(select(history, available = { it.id != "s1" })))
    }

    @Test
    fun `unknown song ids are ignored`() {
        assertEquals(listOf("s1"), ids(select(queue = listOf("missing", "s1"))))
    }

    @Test
    fun `limit is respected`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        assertEquals(2, select(history, limit = 2).songs.size)
    }

    @Test
    fun `artist filter keeps only that artist`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        val result = select(history, filter = OfflineBackupFilter(artistIds = setOf("a1")))
        assertEquals(setOf("s1", "s4"), ids(result).toSet())
    }

    @Test
    fun `mood filter uses artist tags`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        assertEquals(setOf("s3"), ids(select(history, filter = OfflineBackupFilter(moods = setOf(Mood.PEACEFUL)))).toSet())
        assertEquals(setOf("s1", "s4"), ids(select(history, filter = OfflineBackupFilter(moods = setOf(Mood.ROMANTIC)))).toSet())
        assertEquals(setOf("s2"), ids(select(history, filter = OfflineBackupFilter(moods = setOf(Mood.ENERGETIC)))).toSet())
    }

    @Test
    fun `genre filter uses artist tags`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        val result = select(history, filter = OfflineBackupFilter(genres = setOf("metal")))
        assertEquals(listOf("s2"), ids(result))
    }

    @Test
    fun `filters combine with AND across groups`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        val filter = OfflineBackupFilter(artistIds = setOf("a1"), moods = setOf(Mood.PEACEFUL))
        assertTrue(select(history, filter = filter).songs.isEmpty())
    }

    @Test
    fun `artists without tag data are excluded from mood views but kept otherwise`() {
        val untagged = song("s9", ArtistEntity(id = "a9", name = "Nobody"))
        val all = songs + (untagged.id to untagged)
        val history = all.keys.map { HistoryEntry(it, now) }
        val moodView =
            OfflineBackupSelector.select(history, emptyList(), all, { true }, { tags[it] }, OfflineBackupFilter(moods = setOf(Mood.SAD)), now)
        assertFalse("s9" in ids(moodView))
        val plain = OfflineBackupSelector.select(history, emptyList(), all, { true }, { tags[it] }, OfflineBackupFilter(), now)
        assertTrue("s9" in ids(plain))
    }

    @Test
    fun `facets list only what the playable songs offer`() {
        val history = listOf(HistoryEntry("s1", now), HistoryEntry("s3", now))
        val facets = select(history).facets
        assertEquals(listOf("a1", "a3"), facets.artists.map { it.id })
        assertTrue(Mood.ROMANTIC in facets.moods && Mood.PEACEFUL in facets.moods)
        assertFalse(Mood.ENERGETIC in facets.moods)
        assertTrue("bollywood" in facets.genres)
        assertFalse("metal" in facets.genres)
        assertFalse("seen live" in facets.genres)
    }

    @Test
    fun `facets are built before the filter is applied`() {
        val history = songs.keys.map { HistoryEntry(it, now) }
        val result = select(history, filter = OfflineBackupFilter(artistIds = setOf("a2")))
        assertEquals(3, result.facets.artists.size)
    }
}
