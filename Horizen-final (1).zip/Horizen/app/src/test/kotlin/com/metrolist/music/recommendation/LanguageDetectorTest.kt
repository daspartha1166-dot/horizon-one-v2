/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.recommendation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LanguageDetectorTest {
    @Test
    fun `native scripts are detected`() {
        assertEquals(MusicLanguage.BENGALI, LanguageDetector.detect("মান্না দে।। Best of Manna Dey।।"))
        assertEquals(MusicLanguage.TAMIL, LanguageDetector.detect("அனிருத் ஹிட்ஸ்"))
        assertEquals(MusicLanguage.TELUGU, LanguageDetector.detect("తెలుగు పాటలు"))
        assertEquals(MusicLanguage.MALAYALAM, LanguageDetector.detect("മലയാളം ഗാനങ്ങൾ"))
        assertEquals(MusicLanguage.KANNADA, LanguageDetector.detect("ಕನ್ನಡ ಹಾಡುಗಳು"))
        assertEquals(MusicLanguage.PUNJABI, LanguageDetector.detect("ਪੰਜਾਬੀ ਗਾਣੇ"))
        assertEquals(MusicLanguage.HINDI, LanguageDetector.detect("हिंदी गाने"))
    }

    @Test
    fun `language names in latin script are detected`() {
        assertEquals(MusicLanguage.BENGALI, LanguageDetector.detect("Popular Bangla song | Sobai To Sukhi Hote Chai"))
        assertEquals(MusicLanguage.PUNJABI, LanguageDetector.detect("Latest Punjabi Songs 2023"))
        assertEquals(MusicLanguage.HINDI, LanguageDetector.detect("New Hindi Song 2023 - Arijit Singh"))
    }

    @Test
    fun `specific regional name beats generic hindi`() {
        assertEquals(MusicLanguage.BHOJPURI, LanguageDetector.detect("Bhojpuri hindi mix"))
        assertEquals(MusicLanguage.MARATHI, LanguageDetector.detect("मराठी Marathi गाणी"))
    }

    @Test
    fun `romanised text without a language name is unknown`() {
        assertNull(LanguageDetector.detect("Tum Hi Ho"))
        assertNull(LanguageDetector.detect("Shape of You - Ed Sheeran"))
        assertNull(LanguageDetector.detect(""))
        assertNull(LanguageDetector.detect(null))
    }

    @Test
    fun `english is never inferred from the word english`() {
        assertNull(LanguageDetector.detect("Lata Mangeshkar 1980s film song mix | Lyrics & English"))
    }

    @Test
    fun `artist names containing a language-like word are not enough`() {
        assertNull(LanguageDetector.detect("Raju Punjab - Totte (Official Video)"))
    }

    @Test
    fun `keywords match whole words only`() {
        // "punjab" must not fire inside an unrelated word.
        assertNull(LanguageDetector.detect("Gunjabi remix"))
    }

    @Test
    fun `seed with no languages allows everything`() {
        assertTrue(TasteSeed().allows("Shape of You"))
        assertTrue(TasteSeed().allows("ਪੰਜਾਬੀ ਗਾਣੇ"))
    }

    @Test
    fun `seed blocks other known languages but lets unknown through`() {
        val seed = TasteSeed(languages = setOf(MusicLanguage.HINDI, MusicLanguage.BENGALI))
        assertTrue(seed.allows("हिंदी गाने"))
        assertTrue(seed.allows("বাংলা গান"))
        assertFalse(seed.allows("ਪੰਜਾਬੀ ਗਾਣੇ"))
        assertFalse(seed.allows("Tamil hits jukebox"))
        assertTrue(seed.allows("Tum Hi Ho")) // unknown language is not guessed at
    }

    @Test
    fun `genre tags are used when the title is inconclusive`() {
        val seed = TasteSeed(languages = setOf(MusicLanguage.HINDI))
        assertFalse(seed.allows("Some Song", tagNames = listOf("punjabi", "pop")))
        assertTrue(seed.allows("Some Song", tagNames = listOf("bollywood", "romantic")))
    }

    @Test
    fun `artist boost fades with real history`() {
        val seed = TasteSeed(artistNames = listOf("Arijit Singh"))
        assertEquals(TasteSeed.SEED_ARTIST_BOOST, seed.artistBoost(0), 1e-9)
        assertEquals(TasteSeed.SEED_ARTIST_BOOST / 2, seed.artistBoost(TasteSeed.SEED_FADE_EVENTS.toInt()), 1e-9)
        assertTrue(seed.artistBoost(5000) < 0.2)
        assertTrue(seed.isSeedArtist("arijit singh"))
        assertFalse(seed.isSeedArtist("Shreya Ghoshal"))
    }
}
